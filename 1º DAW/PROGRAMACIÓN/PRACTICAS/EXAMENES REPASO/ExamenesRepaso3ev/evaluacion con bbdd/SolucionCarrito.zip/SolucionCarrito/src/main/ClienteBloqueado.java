package main;

public class ClienteBloqueado extends Exception {

	public ClienteBloqueado(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
