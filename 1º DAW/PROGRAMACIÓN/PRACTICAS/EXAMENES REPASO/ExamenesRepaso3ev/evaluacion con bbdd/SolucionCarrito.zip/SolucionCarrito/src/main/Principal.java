package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bbdd.BD_TiendaCarrito;
import modelos.*;


public class Principal {

	static Scanner sLeer;

	public static void main(String[] args) {
		sLeer = new Scanner(System.in);
		BD_TiendaCarrito bd = new BD_TiendaCarrito("TiendaCarrito");
		int opci;
		boolean PuedeLog = true;
		Path p1 = Paths.get("IntentosFallidos.txt");

		do {

			System.out.println("1.Loguearse | 2.Salir");
			opci = sLeer.nextInt();
			String usuar = "", contra = "";

			if (opci == 1) {
				sLeer.nextLine();
				Cliente usu = null;
				try {

					usu = conectar(bd);

				} catch (ClienteBloqueado e) {
					System.out.println("Has intentado loguearte 3 veces.");
					// Aquí pararía 1 minuto.
					continue;

				} catch (Exception e) {
					System.out.println("Avise a sistemas, error " + e.getMessage());
					continue;
				}

				Vector<CarritoUsu> carrito;

				// Obtengo de la bbdd todos los productos que el usuario tiene en el carrito
				try {
					carrito = bd.CarritoUser(usu.getUsucod());
				} catch (ErrorBaseDatos e) {
					System.out.println("Avise a sistemas, error " + e.getMessage());
					continue;
				}

				Carrito carr = new Carrito(carrito, usu.getUsucod());
				
				System.out.println("Contenido del carrito en memoria:");
				carr.Mostrar();

				int opcium = 0;
				do {
					System.out.println("MENU:");
					System.out.println("1.A�adir al carrito \n2.Borrar del carrito \n3.Comprar del carrito \n4.Logout");
					opcium = sLeer.nextInt();
					switch (opcium) {
					case 1:
						sLeer.nextLine();
						String codpru;
						do {
							System.out.println("Anota el codigo del producto: ");
							codpru = sLeer.nextLine();
						} while (!ValidarCodProdu(codpru));

						System.out.println("�Cu�ntas unidades quiere comprar?");
						int uds = sLeer.nextInt();
						double precio = 0;
						try {
							precio = bd.ProductVerificar(codpru, uds);
						} catch (ErrorBaseDatos e) {
							System.out.println("Avise a sistemas, error " + e.getMessage());
							break;
						} catch (InsuficientesUnidades e) {
							System.out.println("No existe producto o no hay unidades disponibles");
							break;
						}
						carr.add(codpru, uds, precio);
						
						System.out.println("Contenido del carrito en memoria:");
						carr.Mostrar();

						break;
					case 2:
						sLeer.nextLine();

						String idprod = "";
						do {
							System.out.println("Introduce el id del producto a eliminar: ");
							idprod = sLeer.nextLine();
						} while (!ValidarCodProdu(idprod));

						System.out.println("�Cuantas unidades quieres quitar?");
						int unds = sLeer.nextInt();
						if (carr.remove(idprod, unds) == false)
							System.out.println("No se pueden borrar esas unidades de producto.");

						
						System.out.println("Contenido del carrito en memoria:");
						carr.Mostrar();

						break;
					case 3:
						double importe = usu.Comprar(carr.getImportetotal());
						System.out.println("El importe a pagar es de:" + importe);

						try {
							if (usu instanceof ClienteTarjeta)
								bd.actualiz_puntos(((ClienteTarjeta) usu).getPuntos(), carr.getUsucod());
							bd.actualiz_stock(carr.getVcarr());
							bd.vaciar_carrito(carr.getUsucod());
						} catch (ErrorBaseDatos e) {
							System.out.println("Avise a sistemas " + e.getMessage());
						}

						carr.vaciar();

						break;
					case 4:
						try {

							bd.actualiz_carrito(carr.getVcarr(), carr.getUsucod());
						} catch (ErrorBaseDatos e) {
							System.out.println("Avise a sistemas " + e.getMessage());
						}

						carr.vaciar();
						break;

					}
				} while (opcium != 4);

			}
		} while (opci != 2);
		System.out.println("Terminado el programa...");
		// Falta array de frecuencias
		sLeer.nextLine();
		System.out.println("Introduce una fecha:(dd/mm/aa) ");
		String fecha = sLeer.nextLine();
		FechaIncidencia(fecha, p1);

	}

	public static boolean ValidarCodProdu(String codprod) {
		return codprod.matches("[A-Z]{2,3}[0-9]{2,3}");
	}

	public static void FechaIncidencia(String fecha, Path p1) {
		Charset chars = Charset.forName("UTF-8");
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/LL/yy");
		LocalDate lccdt=LocalDate.parse(fecha,dtf);
		try {
			BufferedReader br = Files.newBufferedReader(p1, chars);
			String line = "";
			System.out.println("Accesos Fallidos: ");
			while ((line = br.readLine()) != null) {
				String[] tr = line.split(",");
				LocalDate lddt = LocalDate.parse(tr[1],dtf);
				if (lddt.isBefore(lccdt)) {
					System.out.println(line);
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static Cliente conectar(BD_TiendaCarrito bd) throws ErrorBaseDatos, ClienteBloqueado, IOException {
		Cliente cli;
		String usuar, contra;
		int intentos = 0;
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/LL/yy");
		do {
			System.out.println("Codigo usuario: ");
			usuar = sLeer.nextLine();
			System.out.println("Contraseña Usuario: ");
			contra = sLeer.nextLine();
			try {
				cli = bd.SacarUsu(usuar, contra);
			} catch (ErrorBaseDatos e) {
				throw e;
			}
			intentos++;
		} while (cli == null && intentos < 3);

		if (intentos == 3) {
			Path p1 = Paths.get("IntentosFallidos.txt");
			Charset chars = Charset.forName("UTF-8");
			BufferedWriter bw;
			try {
				bw = Files.newBufferedWriter(p1, chars, StandardOpenOption.APPEND, StandardOpenOption.CREATE);
			} catch (IOException e) {
				throw e;
			}
			bw.write(usuar + "," + LocalDate.now().format(dtf));
			bw.newLine();
			bw.close();
			throw new ClienteBloqueado("Cliente bloqueado");
		}
		return cli;
	}

}
