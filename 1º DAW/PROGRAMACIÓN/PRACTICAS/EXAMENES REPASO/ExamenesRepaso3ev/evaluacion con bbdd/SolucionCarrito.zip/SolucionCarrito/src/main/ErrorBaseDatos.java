package main;

public class ErrorBaseDatos extends Exception {

	
	public ErrorBaseDatos(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
