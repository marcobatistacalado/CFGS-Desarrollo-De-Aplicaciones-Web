package bbdd;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import main.ClienteBloqueado;
import main.ErrorBaseDatos;
import main.InsuficientesUnidades;
import modelos.*;

public class BD_TiendaCarrito extends BD_Conector {
	private static Statement s;
	private static ResultSet reg;
	

	public BD_TiendaCarrito(String bbdd) {
		super(bbdd);
		// TODO Auto-generated constructor stub
	}

	public Cliente SacarUsu(String codusu, String passwd) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * from clientes WHERE codigousuario='" + codusu + "' AND password='" + passwd + "'";
		Cliente cli = null;

		try {

			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				if (reg.getString("tarjeta") == "") {
					cli = new ClienteNormal(codusu, passwd, reg.getString("NOMBRE"));

				} else {
					cli = new ClienteTarjeta(codusu, passwd, reg.getString("NOMBRE"), reg.getString("tarjeta"),
							reg.getInt("puntos"));

				}
			}
			s.close();
			this.cerrar();

			return cli;
		} catch (SQLException e) {
			throw new ErrorBaseDatos(e.getMessage());

		}
	}

	public String buscarCarr(String id) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT idproducto from carrito WHERE idproducto = '" + id + "'";
		Vector<String> vejemplo = new Vector<String>();
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			String idxd;
			if (reg.next()) {
				idxd = reg.getString("idproducto");
				s.close();
				this.cerrar();
				return idxd;

			}
			s.close();
			this.cerrar();
			return null;
		} catch (SQLException e) {
			throw new ErrorBaseDatos(e.getMessage());

		}
	}

	public Vector<CarritoUsu> CarritoUser(String codusu) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * from carrito WHERE codigousuario ='" + codusu + "'";
		Vector<CarritoUsu> vejemplo = new Vector<CarritoUsu>();
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				vejemplo.add(new CarritoUsu(codusu, reg.getInt("numero"), reg.getString("idproducto"),
						reg.getInt("unidades"), reg.getDouble("preciounidad")));

			}
			s.close();
			this.cerrar();
			return vejemplo;
		} catch (SQLException e) {
			throw new ErrorBaseDatos(e.getMessage());

		}
	}

	public double ProductVerificar(String codpro, int uds) throws ErrorBaseDatos, InsuficientesUnidades {
		double precio = 0;
		String cadenaSQL = "SELECT precio, stock from productos WHERE identificador ='" + codpro + "'";
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				if (reg.getInt("stock") >= uds) {
					precio = reg.getDouble("precio");
				}
			}
			s.close();
			this.cerrar();
			if (precio == 0)
				throw new InsuficientesUnidades("No existe / No hay unidades");
			return precio;
		} catch (SQLException e) {
			throw new ErrorBaseDatos(e.getMessage());

		}
	}

	public int InsertarCarrito(CarritoUsu tar1) throws ErrorBaseDatos {
		String sql = "INSERT INTO carrito (codigousuario, numero, idproducto, unidades, preciounidad) VALUES ('?', '?', '?', '?', '?')";
		try {
			this.abrir();
			PreparedStatement ps = c.prepareStatement(sql);
			ps.setString(1, tar1.getCodusuario());
			ps.setInt(2, tar1.getNumero());
			ps.setString(3, tar1.getIdProducto());
			ps.setInt(4, tar1.getUnidades());
			ps.setDouble(5, tar1.getPrecioud());

			int filas = ps.executeUpdate();
			System.out.println("Filas afectadas: " + filas);
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos(e.getMessage());

		}
	}

	public int actualiz_puntos(int puntos, String codusu) throws ErrorBaseDatos {
		String cadenaSQL = "UPDATE clientes SET puntos = '" + puntos + "' WHERE codigousuario = '" + codusu + "'";
		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadenaSQL);
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos(e.getMessage());

		}
	}

	public int actualiz_stock(Vector<CarritoUsu> v) throws ErrorBaseDatos {
		int filas = 0;
		String cadenaSQL = "UPDATE productos SET stock = stock - ? WHERE identificador = ?";
		try {
			this.abrir();
			PreparedStatement p = c.prepareStatement(cadenaSQL);
			for (CarritoUsu ca : v) {
				p.setInt(1, ca.getUnidades());
				p.setString(2, ca.getIdProducto());
				filas += p.executeUpdate();
			}
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos(e.getMessage());

		}
	}
	
	public void vaciar_carrito(String codUsu) throws ErrorBaseDatos {
		String cadenaSQL1 = "DELETE FROM carrito WHERE codigousuario = '" + codUsu + "'";
		
		
		try {
			this.abrir();
			s = c.createStatement();
			s.executeUpdate(cadenaSQL1);
			s.close();
			
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos(e.getMessage());

		}
	}


	public int actualiz_carrito(Vector<CarritoUsu> carr, String codUsu) throws ErrorBaseDatos {
		
		String cadenaSQL2 = "insert into carrito VALUES('" + codUsu + "',?,?,?,?)";
		int cont = 1;
		int filasAfect = 0;
		try {
			this.abrir();
			
			// Insertamos los nuevos elementos del carrito
			PreparedStatement p = c.prepareStatement(cadenaSQL2);
			for (CarritoUsu ca : carr) {
				p.setInt(1, cont);
				cont++;
				p.setString(2, ca.getIdProducto());
				p.setInt(3, ca.getUnidades());
				p.setDouble(4, ca.getPrecioud());

				filasAfect += p.executeUpdate();
			}
			p.close();
			s.close();
			this.cerrar();
			return filasAfect;

		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos(e.getMessage());

		}
	}

	public String[] arrfcodig() throws ErrorBaseDatos {
		String cadenaSQL = "SELECT identificador from productos";
		try {
			int cont = 0;
			this.abrir();

			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				cont++;

			}
			String[] strg = new String[cont];
			reg.beforeFirst();
			cont = 0;
			while (reg.next()) {
				strg[cont] = reg.getString("identificador");
				cont++;
			}
			s.close();
			this.cerrar();
			return strg;
		} catch (SQLException e) {
			throw new ErrorBaseDatos(e.getMessage());

		}
	}
}

