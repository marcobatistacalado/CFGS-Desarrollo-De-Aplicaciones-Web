package colegio;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.sql.*;

import bbdd.*;
import modelos.Alumno;
import modelos.Curso;

public class Principal {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int opc = 0;

		BD_Colegio bd = new BD_Colegio("mysql-properties.xml");

		do {
			System.out.println("\n\nGESTI�N COLEGIO");
			System.out.println("***************");
			System.out.println("1.Nuevo Alumno\n" + "2.Nuevo Curso\n3.Borrar Alumno\n4.Listado alumnos por curso\n"
					+ "5.Listado de cursos\n" + "6.Consultar alumno\n" + "7.Consultar tutor de un curso\n"
					+ "8.Listado alumnos por tutor\n" + "9.Listado alumnos por curso de todos los cursos");
			System.out.print("\tTeclea opci�n: ");
			try {
				opc = sc.nextInt();
			}

			catch (InputMismatchException e) {
				System.out.println("Debes introducir n�mero 1-5");
				opc = 0;
			}

			sc.nextLine();// Limpiar buffer
			String nombre, descripcion, aula, dni, telefono, curso;
			int matricula;
			Vector<String> cursos;
			switch (opc) {
			case 1: // 1.Nuevo Alumno
				System.out.println("\n\nALTA ALUMNO");
				System.out.print("Introduce nombre completo\t");
				nombre = sc.nextLine();
				System.out.print("Introduce telefono\t");
				telefono = sc.nextLine();
				System.out.print("Introduce DNI\t");
				dni = sc.nextLine();
				System.out.print("Introduce n�mero de matr�cula\t");
				matricula = sc.nextInt();
				try {
					cursos = bd.listadoCursos();
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}
				if (cursos == null) {
					System.out.println("No hay cursos disponibles");
					break;
				}
				System.out.println("Lista de cursos");
				for (int i = 0; i < cursos.size(); i++)
					System.out.println(cursos.get(i));
				System.out.print("Teclea el curso\t");
				curso = sc.next();
				Alumno al = new Alumno(dni, nombre, curso, matricula, telefono);
				int filas;
				try {
					filas = bd.añadir_Alumno(al);
					switch (filas) {
					case 1:
						System.out.println("\nAlumno a�adido");
						break;
					case 0:
						System.out.println("\nNo a�adido, contacte con sistemas");
						break;

					}
				} catch (ErrorBaseDatos e) {
					// TODO Auto-generated catch block
					System.out.println("Contacte con sistemas:" + e.getMessage());
				}

				break;

			case 2: // Nuevo Curso
				System.out.println("Alta Curso");
				System.out.print("Introduce nombre del curso:");
				nombre = sc.nextLine();
				System.out.print("Introduce descripcion:");
				descripcion = sc.nextLine();
				System.out.print("Introduce aula:");
				aula = sc.nextLine();

				Curso c1 = new Curso(descripcion, nombre, aula);

				try {
					// hacer el insert
					filas = bd.añadir_Curso(c1);
					switch (filas) {
					case 1:
						System.out.println("Curso a�adido");
						break;
					case 0:
						System.out.println("\nNo a�adido, contacte con sistemas");
						break;
					}
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}
				break;

			case 3: // borrar alumno
				System.out.println("Anota el DNI:");
				dni = sc.nextLine();
				try {
					// hacer el delete
					filas = bd.borrar_Alumno(dni);
					switch (filas) {
					case 1:
						System.out.println("Curso a�adido");
						break;
					case 0:
						System.out.println("\nNo a�adido, contacte con sistemas");
						break;
					}
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}
				break;

			case 4: // listado alumnos por curso
				cursos = null;
				try {

					cursos = bd.listadoCursos();

				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}
				if (cursos == null) {
					System.out.println("No hay cursos disponibles");
					break;
				}
				System.out.println("Lista de cursos");
				for (int i = 0; i < cursos.size(); i++)
					System.out.println(cursos.get(i).toString());

				System.out.print("Teclea el curso del cual quieres ver los alumnos\t");
				curso = sc.next();
				Vector<Alumno> listado = null;
				try {
					listado = bd.listadoAlumnosCurso(curso);
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}

				System.out.println("\n\nLISTADO ALUMNOS " + curso.toUpperCase() + "\n");
				for (int i = 0; i < listado.size(); i++)
					System.out.println(listado.get(i).toString());
				break;
			case 5: // listado cursos
				ArrayList cursosTotal = null;

				try {
					cursosTotal = bd.listadoCursosCompleto();
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}

				if (cursosTotal == null) {
					System.out.println("No hay cursos disponibles");
					break;
				}
				System.out.println("Lista de cursos:");
				System.out.println("Lista de cursos");
				for (int i = 0; i < cursosTotal.size(); i++)
					System.out.println(cursosTotal.get(i).toString());
				break;

			case 6: // consultar alumno
				System.out.println("Introduce dni alumno:");
				dni = sc.nextLine();
				try {
					if (bd.mostrarAlumno(dni) != null) {
						System.out.println(bd.mostrarAlumno(dni).toString());
					} else {
						System.out.println("No se ha encontrado");
					}
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}

				break;
			case 7: // Consultar tutor de un curso
				System.out.println("Introduce curso:");
				curso = sc.nextLine();

				try {
					if (bd.tutorCurso(curso) != null) {
						System.out.println(bd.tutorCurso(curso).toString());
					} else {
						System.out.println("No se ha encontrado");
					}
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}
				break;
			case 8:// Listado alumnos por tutor
				System.out.println("Introduce dni del tutor:");
				dni = sc.nextLine();

				try {
					ArrayList alumnosxTutor = null;
					alumnosxTutor = bd.listadoAlumnoxTutor(dni);
					if (alumnosxTutor != null) {
						for (int i = 0; i < alumnosxTutor.size(); i++) {
							System.out.println(alumnosxTutor.get(i).toString());
						}
					} else {
						System.out.println("No se ha encontrado");
					}
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}
				break;

			case 9:
				try {
					bd.listadoDeAlumnosCurso();
				} catch (ErrorBaseDatos e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 10:
				// arraylist de alumnos y insertarlos con lo nuevo de BBDD CON PREPARESTATEMENT
				ArrayList<Curso> cursos2 = new ArrayList<Curso>();
				String seguir;
				do {
					System.out.println("Anota curso:");
					String n = sc.nextLine();
					System.out.println("Anota descripcion:");
					String descrp = sc.nextLine();
					System.out.println("Anota aula:");
					String aul = sc.nextLine();
					cursos2.add(new Curso(descrp, n, aul));
					System.out.println("¿otro curso S/N?");
					seguir = sc.nextLine();
				} while (seguir.equalsIgnoreCase("S"));

				try {
					bd.añadir_Curso2(cursos2);
					System.out.println("Alta de cursos realizada");
				} catch (ErrorBaseDatos e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}

				break;
			}
		} while (opc != 10);

	}

}
