package modelos;

public class Tutor extends Persona {

	public Tutor(String dni, String nombre, String curso) {
		super(dni, nombre, curso);
		// TODO Auto-generated constructor stub
	}

}
