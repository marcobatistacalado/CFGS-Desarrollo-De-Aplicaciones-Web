package bbdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.*;
import colegio.*;
import modelos.*;

public class BD_Colegio extends BD_Conector {

	private static Statement s;
	private static ResultSet reg;

	public BD_Colegio(String file) {
		super(file);
	}

	public void listadoDeAlumnosCurso() throws ErrorBaseDatos{
		
		try{
			//conseguir vector de todos los cursos: listadoCursos
			Vector<String> listaCursos = listadoCursos();
			for (int i = 0; i<listaCursos.size(); i++) {
				System.out.println(listaCursos.get(i).toString());
				Vector <Alumno> alumnos = listadoAlumnosCurso(listaCursos.get(i).toString());
				for (int j = 0; j<alumnos.size(); j++) {
				System.out.println(alumnos.get(j).toString());
				}
			}
			
		}
		catch ( ErrorBaseDatos e){		
			e.printStackTrace();
		}
	}

	public ArrayList<Alumno> listadoAlumnoxTutor(String dni) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM alumnos WHERE CURSO = (SELECT curso FROM tutores WHERE dni='" + dni + "')";
		ArrayList<Alumno> listadoAlumnosxTutor = new ArrayList<Alumno>();

		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				// String dni, String nombre, String curso, int matricula, String telenono,
				// LocalDate fechaMatricula
				listadoAlumnosxTutor.add(new Alumno(reg.getString(2), reg.getString(1), reg.getString(5), reg.getInt(4),
						reg.getString(3), reg.getDate(6).toLocalDate()));
			}
			s.close();
			this.cerrar();
			return listadoAlumnosxTutor;
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos("Listando cursos");

		}
	}

	public Tutor tutorCurso(String curso) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * from tutores WHERE curso='" + curso + "'";
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (!reg.next()) {
				return null; // ns si esta bn
			}
			// String dni, String nombre, String curso
			Tutor t = new Tutor(reg.getString(1), reg.getString(2), reg.getString(3));
			s.close();
			this.cerrar();
			// dni, nombre, curso, matricula, telefono
			return t;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("Mostrando alumno");
		}
	}

	public Alumno mostrarAlumno(String dni) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * from alumnos WHERE dni='" + dni + "'";
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (!reg.next()) {
				return null;
			}
			// String dni, String nombre, String curso, int matricula, String telenono,
			// LocalDate fechaMatricula
			Alumno a = new Alumno(reg.getString(2), reg.getString(1), reg.getString(5), reg.getInt(4), reg.getString(3),
					reg.getDate(6).toLocalDate());
			s.close();
			this.cerrar();
			// dni, nombre, curso, matricula, telefono
			return a;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("Mostrando alumno");
		}
	}

	public ArrayList<Curso> listadoCursosCompleto() throws ErrorBaseDatos {
		String cadenaSQL = "SELECT curso, descripcion, aula from cursos";
		ArrayList<Curso> listaCursos = new ArrayList<Curso>();
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				// el orden del objeto es: descripcion, curso, aula. Por eso hay que saber que
				// coger del select.
				listaCursos.add(new Curso(reg.getString(2), reg.getString(1), reg.getString(3)));
			}
			s.close();
			this.cerrar();
			return listaCursos;
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos("Listando cursos");

		}
	}

	public int borrar_Alumno(String dni) throws ErrorBaseDatos {
		String cadenaSQL = "DELETE FROM alumnos WHERE dni ='" + dni + "'";

		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadenaSQL);
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se puede realizar el alta");
		}
	}

	public int añadir_Alumno(Alumno al) throws ErrorBaseDatos {
		String cadenaSQL = "INSERT INTO alumnos VALUES('" + al.getNombre() + "','" + al.getDni() + "','"
				+ al.getTelenono() + "'," + al.getMatricula() + ",'" + al.getCurso() + "','" + al.getFechaMatricula()
				+ "')";

		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadenaSQL);
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se puede realizar el alta");
		}
	}

	public Vector<Alumno> listadoAlumnosCurso(String curso) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * from alumnos WHERE curso='" + curso + "'";
		Vector<Alumno> listaCursos = new Vector<Alumno>();
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				// La fecha que se extrae de la bbdd es sql.Date, hay que transformarla a
				// LocalDate
				java.sql.Date f = reg.getDate("fechaMatricula");
				LocalDate fBuena = f.toLocalDate();
				listaCursos.add(new Alumno(reg.getString("dni"), reg.getString("nombre"), reg.getString("curso"),
						reg.getInt("matricula"), reg.getString("telefono"), fBuena));

			}
			s.close();
			this.cerrar();
			return listaCursos;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("Listando alumnos curso");
		}
	}

	public Vector<String> listadoCursos() throws ErrorBaseDatos {
		String cadenaSQL = "SELECT curso from cursos";
		Vector<String> listaCursos = new Vector<String>();
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				listaCursos.add(reg.getString(1));
			}
			s.close();
			this.cerrar();
			return listaCursos;
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos("Listando cursos");

		}
	}

	public void listadoAlumnosPorCurso() throws ErrorBaseDatos {
		String cadenaSQL = "SELECT curso from cursos";
		String curso = "";
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				curso = reg.getString(1);
				System.out.println("CURSO:" + curso);
				Statement s2 = c.createStatement();
				ResultSet reg2 = s2.executeQuery("select nombre from alumnos where curso='" + curso + "'");
				while (reg2.next()) {
					System.out.println("\t" + reg2.getString(1));
				}
				s2.close();
			}
			s.close();
			this.cerrar();
			return;
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos("Listando cursos");

		}
	}

	public int añadir_Curso(Curso curso) throws ErrorBaseDatos {
		String cadenaSQL = "INSERT INTO cursos VALUES('" + curso.getCurso() + "','" + curso.getDescripcion() + "','"
				+ curso.getAula() + "')";

		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadenaSQL);
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se puede realizar el alta");
		}
	}
	
	public int añadir_Curso2(ArrayList<Curso> acursos) throws ErrorBaseDatos {
		String cadenaSQL = "INSERT INTO cursos VALUES(?,?,?)";
		/*
		String cadenaSQL = "INSERT INTO cursos VALUES('" + curso.getCurso() + "','" + curso.getDescripcion() + "','"
				+ curso.getAula() + "')";
*/		
		try {
			this.abrir();
			//pasamos la cadena al statement: la BBDD precompila
			//MUCHISIMO MAS RAPIDO QUE HACER FOR HE IR HACIENDO EJECUCION DE STATEMENTS --> INSERTAR VARIAS FILAS
			PreparedStatement p = c.prepareStatement(cadenaSQL);
			//recorreos el arrayList
			for (Curso c : acursos) {
				p.setString(1, c.getCurso());
				p.setString(2, c.getDescripcion());
				p.setString(3, c.getAula());
				p.executeUpdate(); //lo ejecutamos sin pasarle nada porque ya lo he construido
			}
			p.close();
			this.cerrar();
			return acursos.size();
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se puede realizar el alta");
		}
	}

}
