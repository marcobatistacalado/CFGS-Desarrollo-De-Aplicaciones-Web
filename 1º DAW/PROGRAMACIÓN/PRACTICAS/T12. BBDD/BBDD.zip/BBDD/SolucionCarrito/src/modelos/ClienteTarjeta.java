package modelos;

public class ClienteTarjeta extends Cliente {

	protected String PuntosTarjeta;
	protected int puntos;

	public ClienteTarjeta(String usucod, String password, String telefono, String puntos, int punttos) {
		super(usucod, password, telefono);
		this.PuntosTarjeta = puntos;
		// TODO Auto-generated constructor stub
	}
	
	public int getPuntos() {
		return puntos;
	}

	@Override
	public double Comprar(double importe) {
		puntos+=(importe/20)*3;		
		return importe;
	}
	
	

}
