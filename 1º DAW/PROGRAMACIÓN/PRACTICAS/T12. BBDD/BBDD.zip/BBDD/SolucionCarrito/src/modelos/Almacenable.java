package modelos;

public interface Almacenable {

		public void vaciar();
		public void Mostrar();
}
