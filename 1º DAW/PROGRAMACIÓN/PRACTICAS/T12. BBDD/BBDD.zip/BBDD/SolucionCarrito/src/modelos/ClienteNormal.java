package modelos;

public class ClienteNormal extends Cliente {

	public ClienteNormal(String usucod, String password, String telefono) {
		super(usucod, password, telefono);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double Comprar(double importe) {
		if (importe < 100) {
			importe = importe + 7;
		}
		return importe;
	}
	
	

}
