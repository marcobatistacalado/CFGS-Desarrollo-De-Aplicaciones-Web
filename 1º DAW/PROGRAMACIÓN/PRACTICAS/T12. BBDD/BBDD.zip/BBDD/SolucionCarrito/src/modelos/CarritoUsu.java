package modelos;

public class CarritoUsu {
	protected String codusuario;
	protected int numero;
	protected String idProducto;
	protected int unidades;
	protected double precioud;

	public CarritoUsu(String codusuario, int numero, String idProducto, int unidades, double precioud) {
		super();
		this.codusuario = codusuario;
		this.numero = numero;
		this.idProducto = idProducto;
		this.unidades = unidades;
		this.precioud = precioud;
	}

	public String getCodusuario() {
		return codusuario;
	}

	public int getNumero() {
		return numero;
	}

	public String getIdProducto() {
		return idProducto;
	}

	public int getUnidades() {
		return unidades;
	}

	public void setUnidades(int nuevo) {
		unidades += nuevo;
	}

	public boolean restUnidades(int restar) {
		if (unidades >= restar) {
			unidades = unidades - restar;
			return true;
		}
		return false;
	}

	public double getPrecioud() {
		return precioud;
	}

	@Override
	public String toString() {
		return "CarritoUsu [codusuario=" + codusuario + ", numero=" + numero + ", idProducto=" + idProducto
				+ ", unidades=" + unidades + ", precioud=" + precioud + "]";
	}

}
