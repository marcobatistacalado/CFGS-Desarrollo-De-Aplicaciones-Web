package main;

public class InsuficientesUnidades extends Exception {

	public InsuficientesUnidades(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
