package modelos;

public class Producto {

	protected String productID;
	protected String nombre;
	protected double precio;
	protected int Stock;
	
	public Producto(String productID, String nombre, double precio, int stock) {
		super();
		this.productID = productID;
		this.nombre = nombre;
		this.precio = precio;
		Stock = stock;
	}

	public String getProductID() {
		return productID;
	}

	public String getNombre() {
		return nombre;
	}

	public double getPrecio() {
		return precio;
	}

	public int getStock() {
		return Stock;
	}
	
	
	
}
