package modelos;

import java.util.Vector;

public class Carrito implements Almacenable {
	
	protected Vector<CarritoUsu> vcarr;
	protected String usucod;
	protected double importeTotal;
	protected int unidadesTotal;
	
	public Carrito(Vector<CarritoUsu> vcarr, String usucod) {
		int cont = 0;
		double importet=0;
		this.vcarr = vcarr;
		this.usucod = usucod;
			
		for(int i =0;i<vcarr.size();i++) {
			cont++;
			importet += (vcarr.get(i).getUnidades() * vcarr.get(i).getPrecioud());
		}
		unidadesTotal = cont;
		importeTotal = importet;
	}
	
	@Override
	public void vaciar() {
		vcarr.clear();
		importeTotal = 0;
		unidadesTotal = 0;
		
	}
	
	public void add(String prod, int unidades, double precio) {
		boolean encontrado=false;
		for(int i = 0;i<vcarr.size();i++) {
			if (vcarr.get(i).getIdProducto().equals(prod)) {
				vcarr.get(i).setUnidades(unidades);
				unidadesTotal+=unidades;
				importeTotal+=unidades*precio;
				encontrado=true;
				break;
			}
		}
		if (!encontrado)
			vcarr.add(new CarritoUsu(usucod,0,prod,unidades,precio));
	}
	
	public boolean remove(String prod, int unidades) {
	
		for(int i = 0;i<vcarr.size();i++) {
			if (vcarr.get(i).getIdProducto().equals(prod)) {
				if (vcarr.get(i).restUnidades(unidades)) {
					unidadesTotal-=unidades;
					importeTotal-=unidades*vcarr.get(i).getPrecioud();
					if (vcarr.get(i).getUnidades()==0)
						vcarr.remove(i);
					return true;
				}
				else
					return false;
				
				
			}
		}
		return false;
	}

	@Override
	public void Mostrar() {
		for(int i = 0;i<vcarr.size();i++) {
			System.out.println(vcarr.get(i).toString());
		}
		System.out.println("Codigo usuario: "+usucod +" | Importe total: "+importeTotal+" | Unidades total: "+unidadesTotal);
	}

	public Vector<CarritoUsu> getVcarr() {
		return vcarr;
	}

	public String getUsucod() {
		return usucod;
	}

	public double getImportetotal() {
		return importeTotal;
	}

	public int getUnidadesTotal() {
		return unidadesTotal;
	}
	
	public void setImportetotal(double importe) {
		importeTotal = importe;
	}
	
	
}
