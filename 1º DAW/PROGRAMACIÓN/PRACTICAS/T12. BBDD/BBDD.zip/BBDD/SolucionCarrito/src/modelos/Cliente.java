package modelos;

public abstract class Cliente {
	protected String usucod;
	protected String password;
	protected String telefono;
	
	public Cliente(String usucod, String password, String telefono) {
		super();
		this.usucod = usucod;
		this.password = password;
		this.telefono = telefono;
	}

	public String getUsucod() {
		return usucod;
	}

	public String getPassword() {
		return password;
	}

	public String getTelefono() {
		return telefono;
	}
	
	public abstract double Comprar(double importe);
}
