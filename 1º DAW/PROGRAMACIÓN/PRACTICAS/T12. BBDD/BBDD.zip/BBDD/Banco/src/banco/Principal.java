package banco;

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.sql.*;

import bbdd.*;
import modelos.*;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		BD_Banco bd = new BD_Banco("mysql-properties.xml");
		int opc;
		do {
			System.out.println();
			System.out.println("1.Alta tarjeta crédito\n2.Alta tarjeta débito\n3.Sacar dinero tarjeta débito"
					+ "\n4.Sacar dinero tarjeta crédito\n5.Movimientos cargados tarjeta crédito\n"
					+ "6.Mostrar tarjetas e info cuenta\n" + "7.Cargar movimientos de fichero\n");
			System.out.print("\tTeclea opción: ");
			try {
				opc = sc.nextInt();
			}

			catch (InputMismatchException e) {
				System.out.println("Debes introducir n�mero 1-5");
				opc = 0;
			}
			sc.nextLine(); // Limpiar buffer.
			switch (opc) {
			case 1: // Alta tarjeta crédito
				System.out.println("\n\nALTA TARJETA CRÉDITO");
				System.out.println("Introduce DNI: ");
				String dni = sc.nextLine();
				try {
					Vector<Cuenta> listaCuentas = bd.listarCuentasTitular(dni);
					if (listaCuentas != null) {
						for (Cuenta c : listaCuentas) {
							System.out.println(c.toString());
						}
						System.out.println("Selecciona una de las cuentas:");
						int cuenta = sc.nextInt();
						boolean correcto = false;
						for (Cuenta c : listaCuentas) {
							if (c.getnC() == cuenta) {
								correcto = true;
							}
						}
						if (!correcto) {
							System.out.println("Esa cuenta no es la correcta.");
						} else {
							// crear tarjeta
							int limite = 0;
							do {
								System.out.println("Introduce límite (menor que 1000)");
								limite = sc.nextInt();
							} while (limite > 1000 || limite < 0);
							boolean tarjetaExistente = false;
							int numTarjeta;
							do {
								System.out.println("Introduce numero de la tarjeta");
								numTarjeta = sc.nextInt();
								tarjetaExistente = bd.buscarTarjetaExistente(numTarjeta);
								if (tarjetaExistente) {
									System.out.println("Esa tarjeta ya existe. Introduce otra:");
								}
							} while (tarjetaExistente);

							// BUSCAR OBJ CUENTA SELECCIONADA SEGUN EL INT
							Cuenta cuentaSeleccionada = cuentaSeleccionada(listaCuentas, cuenta);

							sc.nextLine();// limpiar buffer
							System.out.println("Introduce nombre titular");
							String titular = sc.nextLine();
							int filas;
							try {
								filas = bd.altaTarjetaCredito(cuentaSeleccionada, limite, "C", numTarjeta, titular);
								switch (filas) {
								case 1:
									System.out.println("\nTarjeta Credito Creada");
									break;
								case 0:
									System.out.println("\nNoTarjeta no creada, contacte con sistemas");
									break;

								}
							} catch (ErrorBaseDatos e) {
								// TODO Auto-generated catch block
								System.out.println("Contacte con sistemas:" + e.getMessage());
							}

						}
					} else {
						System.out.println("No se ha encontrado cuentas para este titular");
					}
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}

				break;
			case 2: // Alta tarjeta débito
				System.out.println("\n\nALTA TARJETA DÉBITO");
				System.out.println("Introduce DNI: ");
				dni = sc.nextLine();
				try {
					Vector<Cuenta> listaCuentas = bd.listarCuentasTitular(dni);
					if (listaCuentas != null) {
						for (Cuenta c : listaCuentas) {
							System.out.println(c.toString());
						}
						System.out.println("Selecciona una de las cuentas:");
						int cuenta = sc.nextInt();
						boolean correcto = false;
						for (Cuenta c : listaCuentas) {
							if (c.getnC() == cuenta) {
								correcto = true;
							}
						}
						if (!correcto) {
							System.out.println("Esa cuenta no es la correcta.");
						} else {
							// crear tarjeta
							int numTarjeta;
							numTarjeta = bd.consultarUltimaTarjeta() + 1; // numero tarjeta uno mas alto que el mayor

							// BUSCAR OBJ CUENTA SELECCIONADA SEGUN EL INT
							Cuenta cuentaSeleccionada = cuentaSeleccionada(listaCuentas, cuenta);

							sc.nextLine();// limpiar buffer
							System.out.println("Introduce nombre titular");
							String titular = sc.nextLine();
							int filas;
							try {
								filas = bd.altaTarjetaDebito(cuentaSeleccionada, "D", numTarjeta, titular);
								switch (filas) {
								case 1:
									System.out.println("\nTarjeta Debito Creada");
									break;
								case 0:
									System.out.println("\nNoTarjeta no creada, contacte con sistemas");
									break;

								}
							} catch (ErrorBaseDatos e) {
								// TODO Auto-generated catch block
								System.out.println("Contacte con sistemas:" + e.getMessage());
							}

						}
					} else {
						System.out.println("No se ha encontrado cuentas para este titular");
					}
				} catch (ErrorBaseDatos e) {
					System.out.println("Contacte con sistemas:" + e.getMessage());
					break;
				}
				break;
			case 3: // Sacar dinero tarjeta débito
				System.out.println("\n\nRETIRAR DINERO TARJETA DÉBITO");
				System.out.println("Introduce numero de la tarjeta debito:");
				int tarjeta = sc.nextInt();
				System.out.println("Clave:");
				int clave = sc.nextInt();
				double retirada;
				do {
					System.out.println("¿Cuanto quieres retirar?");
					retirada = sc.nextDouble();
				} while (retirada < 0);
				int consultaTarjeta;
				try {
					consultaTarjeta = bd.consultarTarjeta(tarjeta, clave, "D");
					if (consultaTarjeta == -1) {
						System.out.println("Tarjeta o Clave incorrectos.");
					} else if (consultaTarjeta == 1) {
						System.out.println("Tarjeta bloqueada");
					} else if (consultaTarjeta == -2) {
						System.out.println("La tarjeta no es de débito");
					} else {
						// aqui el pin, y la contraseña son correctos, además no está bloqueada
						int retirardinero = bd.retirarDinero(consultaTarjeta, retirada);
						if (retirardinero == -2) {
							System.out.println("Retirada mayor que el saldo disponible");
						} else if (retirardinero > 0) {
							System.out.println("Retirada con éxito. Recoja los " + retirada + " euros.");
						} else {
							System.out.println("No se ha podido realizar la retirada.");
						}

					}
				} catch (ErrorBaseDatos e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				break;
			case 4: // Sacar dinero tarjeta crédito
				System.out.println("\n\nRETIRAR DINERO TARJETA CRÉDITO");
				System.out.println("Introduce numero de la tarjeta crédito:");
				tarjeta = sc.nextInt();
				System.out.println("Clave:");
				clave = sc.nextInt();
				do {
					System.out.println("¿Cuanto quieres retirar?");
					retirada = sc.nextDouble();
				} while (retirada < 0);
				try {
					consultaTarjeta = bd.consultarTarjeta(tarjeta, clave, "C");
					if (consultaTarjeta == -1) {
						System.out.println("Tarjeta o Clave incorrectos.");
					} else if (consultaTarjeta == 1) {
						System.out.println("Tarjeta bloqueada");
					} else if (consultaTarjeta == -2) {
						System.out.println("La tarjeta no es de crédito");
					} else {
						// aqui el pin, y la contraseña son correctos, además no está bloqueada
						int retirardinero = bd.retirarDinero(consultaTarjeta, retirada);
						if (retirardinero == -2) {
							System.out.println("Retirada mayor que el saldo disponible");
						} else if (retirardinero > 0) {
							System.out.println("Retirada con éxito. Recoja los " + retirada + " euros.");
							if (bd.altaMovimientoTarjeta(tarjeta, retirada) == 0) {
								System.out.println("Alta en movimientos NO HA SIDO POSIBLE.");
							}
						} else {
							System.out.println("No se ha podido realizar la retirada.");
						}

					}
				} catch (ErrorBaseDatos e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				break;
			case 5: // Movimientos cargados tarjeta crédito
				System.out.println("\n\nVIENDO MOVIMIENTOS TARJETA CRÉDITO");
				System.out.println("Introduce tarjeta:");
				tarjeta = sc.nextInt();
				try {
					if (bd.consultarTipoTarjeta(tarjeta).equals("")) {
						System.out.println("No es una tarjeta de crédito");
					} else {
						if (bd.actualizarCargos(tarjeta) == 1) {
							System.out.println("Cargos actualizados");
						} else {
							System.out.println("No tienes cargos pendientes.");
						}
					}
				} catch (ErrorBaseDatos e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				break;
			case 6: // Mostrar tarjetas e info cuenta
				System.out.println("\n\nMOSTRANDO TARJETAS E INFO CUENTAS");
				System.out.println("Nombre titular:");
				String titular = sc.nextLine();
				ArrayList<Cuenta> cuentas = new ArrayList<>();
				try {
					cuentas = bd.consultarTarjetaxTitular(titular);
					for (Cuenta c : cuentas) {
						System.out.println(c.toString());
					}
				} catch (ErrorBaseDatos e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
				break;
			case 7: // Cargar movimientos de fichero
				System.out.println("\n\n CARGANDO MOVIMIENTOS FICHERO");
				Path file = Paths.get("movimientos.txt");
				Charset charset = Charset.forName("UTF-8");
				BufferedReader reader = null;
				ArrayList<Movimiento> movs = new ArrayList<>();
				try {
					// Creamos un BuffereReader de java.io
					reader = Files.newBufferedReader(file, charset);
					String line = null;
					while ((line = reader.readLine()) != null) {
						if (!line.trim().isEmpty()) { // Verificar si la línea no está vacía
							String[] cad = line.split(" ");
							if (cad.length == 5) { // Verificar que la línea tenga 5 elementos
								// Convertir y procesar los datos aquí
								// int nM, int tarjeta, boolean cargado, double importe, LocalDate fecha
								movs.add(new Movimiento(Integer.parseInt(cad[0]), Integer.parseInt(cad[1]),
										Integer.parseInt(cad[2]), Double.parseDouble(cad[3]), LocalDate.parse(cad[4])));
							} else {
								System.out.println("Formato incorrecto en la línea: " + line);
							}
						}
					}
					reader.close();
					if (movs == null) {
						System.out.println("No se han encontrado movimientos");
					} else {
						bd.añadirMovimientos(movs);
						System.out.println("Movimientos subidos con exito");
					}
				} catch (IOException x) {
					System.err.format("IOException: %s%n", x);
				} catch (DateTimeParseException e) {
					System.out.println(e.getMessage());
				} catch (ErrorBaseDatos e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				} finally {
					if (reader != null) {
						try {
							reader.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							System.err.format("IOException: %s%n", e);
						}
					}
				}
				break;
			}
		} while (opc != 10);
	}

	private static Cuenta cuentaSeleccionada(Vector<Cuenta> listaCuentas, int cuenta) {
		for (Cuenta c : listaCuentas) {
			if (c.getnC() == cuenta) {
				return c;
			}
		}
		return null;
	}
}
