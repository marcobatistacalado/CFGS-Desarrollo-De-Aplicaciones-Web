package bbdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.*;
import banco.*;
import modelos.*;

public class BD_Banco extends BD_Conector {

	private static Statement s;
	private static ResultSet reg;

	public BD_Banco(String file) {
		super(file);
	}

	public Vector<Cuenta> listarCuentasTitular(String dni) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM cuentas WHERE titular1='" + dni + "' OR titular2='" + dni + "' OR titular3='"
				+ dni + "'";
		Vector<Cuenta> listaCuentas = new Vector<>();
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				ArrayList<String> titulares = new ArrayList<>();
				titulares.add(reg.getString(2));
				titulares.add(reg.getString(3));
				titulares.add(reg.getString(4));
				java.sql.Date f = reg.getDate("fecha");
				LocalDate fBuena = f.toLocalDate();
				listaCuentas.add(new Cuenta(reg.getInt(1), titulares, reg.getDouble(5), fBuena));
			}
			if (listaCuentas.isEmpty()) {
				listaCuentas = null;
			}
			s.close();
			this.cerrar();
			return listaCuentas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se puede mostrar las cuentas por titular");
		}
	}

	public int altaTarjetaCredito(Cuenta cuenta, int limite, String tipo, int numTarjeta, String titular)
			throws ErrorBaseDatos {
		String cadenaSQL = "INSERT INTO tarjetas VALUES(" + numTarjeta + "," + cuenta.getnC() + ",'" + titular + "',"
				+ limite + ",'" + tipo + "','" + LocalDate.now().plusYears(1) + "',"
				+ ((int) (Math.random() * 9000) + 1000) + "," + 0 + ")";
		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadenaSQL);
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se puede realizar el alta credito");
		}
	}

	public boolean buscarTarjetaExistente(int n) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM tarjetas WHERE numero='" + n + "'";
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			boolean existe = reg.next();
			s.close();
			this.cerrar();
			return existe;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se puede buscar tarjeta existente");
		}
	}

	public int consultarUltimaTarjeta() throws ErrorBaseDatos {
		String cadenaSQL = "SELECT MAX(numero) FROM tarjetas";
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			int maxNumeroTarjeta = 0;
			if (reg.next()) {
				maxNumeroTarjeta = reg.getInt(1);
			}
			s.close();
			this.cerrar();
			return maxNumeroTarjeta;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se puede realizar la consulta de ultima tarjeta");
		}
	}

	public int altaTarjetaDebito(Cuenta cuenta, String tipo, int numTarjeta, String titular) throws ErrorBaseDatos {
		String cadenaSQL = "INSERT INTO tarjetas VALUES(" + numTarjeta + "," + cuenta.getnC() + ",'" + titular + "',"
				+ 0 + ",'" + tipo + "','" + LocalDate.now().plusMonths(6) + "'," + ((int) (Math.random() * 9000) + 1000)
				+ "," + 0 + ")";
		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadenaSQL);
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se puede realizar el alta tarjeta debito");
		}
	}

	public int consultarTarjeta(int tarjeta, int pin, String tipo) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT bloqueada, cuenta, tipo FROM tarjetas WHERE numero = " + tarjeta + " AND clave ="
				+ pin + " ";
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				int devolver = reg.getInt(1);
				if (devolver != 1) {
					return reg.getInt(2);
				}
				return devolver;
			}
			s.close();
			this.cerrar();
			return -1;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se puede realizar la consulta de tarjeta");
		}
	}

	public int retirarDinero(int cuenta, double retirada) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT limite FROM tarjetas WHERE cuenta = " + cuenta + "";
		int filas;
		double sal, lim;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				lim = reg.getDouble(1);
				String cadenaSQL2 = "SELECT saldo FROM cuentas WHERE número = " + cuenta + "";
				reg = s.executeQuery(cadenaSQL2);
				if (reg.next()) {
					sal = reg.getDouble(1);
					if (lim == 0) {
						lim = sal;
					}
					if (lim < retirada) {
						filas = -2;
					} else {
						sal -= retirada;
						String cadenaSQL3 = "UPDATE cuentas SET saldo = " + sal + " WHERE número = " + cuenta + "";
						filas = s.executeUpdate(cadenaSQL3);
					}
					s.close();
					this.cerrar();
					return filas;
				}
			}
			s.close();
			this.cerrar();
			return -1;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se puede realizar la retirada de dinero");
		}
	}

	public double consultarLimiteTarjeta() throws ErrorBaseDatos {
		String cadenaSQL = "SELECT limite FROM tarjetas";
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			double maxNumeroTarjeta = 0;
			if (reg.next()) {
				maxNumeroTarjeta = reg.getInt(1);
			}
			s.close();
			this.cerrar();
			return maxNumeroTarjeta;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se puede realizar el alta");
		}
	}

	public int altaMovimientoTarjeta(int tarjeta, double importe) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT MAX(numero) FROM movimientos";
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			int maxNumeroMov = 0;
			if (reg.next()) {
				maxNumeroMov = reg.getInt(1) + 1;
				String cadenaSQL2 = "INSERT INTO movimientos VALUES(" + maxNumeroMov + "," + tarjeta + "," + 0 + ","
						+ importe + ",'" + LocalDate.now() + "')";
				int filas = s.executeUpdate(cadenaSQL2);
				s.close();
				this.cerrar();
				return filas;
			}
			s.close();
			this.cerrar();
			return 0;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se puede realizar el alta movimiento tarjeta");
		}
	}

	public int actualizarCargos(int tarjeta) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT SUM(importe) FROM movimientos WHERE tarjeta = " + tarjeta + " AND cargado = 0";
		int importeTotal = 0;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				importeTotal = reg.getInt(1);
				if (importeTotal > 0) {
					c.setAutoCommit(false);
					String cadenaSQL2 = "UPDATE movimientos SET cargado = " + 1 + " WHERE tarjeta = " + tarjeta
							+ " AND cargado = 0";
					s.executeUpdate(cadenaSQL2);
					String cadenaSQL3 = "SELECT cuenta FROM tarjetas WHERE numero = " + tarjeta + "";
					reg = s.executeQuery(cadenaSQL3);
					if (reg.next()) {
						int cuenta = reg.getInt(1);
						String cadenaSQL4 = "SELECT saldo FROM cuentas WHERE número = " + cuenta + "";
						reg = s.executeQuery(cadenaSQL4);
						if (reg.next()) {
							double saldo = reg.getDouble(1) - importeTotal;
							String cadenaSQL5 = "UPDATE cuentas SET saldo = " + saldo + " WHERE número = " + cuenta
									+ "";
							if (s.executeUpdate(cadenaSQL5) == 0) {
								System.out.println("No se actualiza el saldo, hago rollback");
								c.rollback();
							}
						}
					}
				}
				s.close();
				c.commit();
				this.cerrar();
				return 1;
			}
			s.close();
			this.cerrar();
			return 0;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se puede actualizar los pagos.");
		}
	}

	public String consultarTipoTarjeta(int tarjeta) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT tipo FROM tarjetas WHERE numero = " + tarjeta + "";
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			String tipo = "";
			if (reg.next()) {
				tipo = reg.getString(1);
			}
			s.close();
			this.cerrar();
			return tipo;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No existe esta tarjeta.");
		}
	}

	public ArrayList<Cuenta> consultarTarjetaxTitular(String titular) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM tarjetas WHERE titular = '" + titular + "' AND caducidad < NOW()";
		ArrayList<Cuenta> cuentas = new ArrayList<>();
		ArrayList<String> tarjetas = new ArrayList<>();
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				tarjetas.add(reg.getString(2));
			}
			String cadenaSQL2;
			for (int i = 0; i < tarjetas.size(); i++) {
				cadenaSQL2 = "SELECT * FROM cuentas WHERE número = " + tarjetas.get(i) + "";
				reg = s.executeQuery(cadenaSQL2);
				if (reg.next()) {
					ArrayList<String> titulares = new ArrayList<>();
					titulares.add(reg.getString(2));
					titulares.add(reg.getString(3));
					titulares.add(reg.getString(4));
					java.sql.Date f = reg.getDate("fecha");
					LocalDate fBuena = f.toLocalDate();
					cuentas.add(new Cuenta(reg.getInt(1), titulares, reg.getDouble(5), fBuena));
				}
			}
			s.close();
			this.cerrar();
			return cuentas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No hay tarjetas asociadas.");
		}
	}

	public int añadirMovimientos(ArrayList<Movimiento> movs) throws ErrorBaseDatos {
		String cadenaSQL = "INSERT INTO movimientos VALUES(?,?,?,?,?)";
		try {
			this.abrir();
			PreparedStatement p = c.prepareStatement(cadenaSQL);
			for (Movimiento m : movs) {
				p.setInt(1, m.getnM());
				p.setInt(2, m.getTarjeta());
				p.setInt(3, m.getCargado());
				p.setDouble(4, m.getImporte());
				java.sql.Date fecha = java.sql.Date.valueOf(m.getFecha());
				p.setDate(5, fecha);
				p.executeUpdate();
			}
			p.close();
			this.cerrar();
			return movs.size();
		} catch (SQLException e) {
			throw new ErrorBaseDatos("No se puede realizar el alta");
		}
	}

}
