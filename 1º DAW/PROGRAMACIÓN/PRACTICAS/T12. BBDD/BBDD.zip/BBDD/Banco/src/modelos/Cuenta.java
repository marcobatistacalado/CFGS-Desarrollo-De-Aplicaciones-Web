package modelos;

import java.time.LocalDate;
import java.util.ArrayList;

public class Cuenta {
	private  int nC;
	private ArrayList <String> titulares; //3 titulares máximo
	private ArrayList <Tarjeta> tarjetas; //es necesario???
	private double saldo;
	private LocalDate fecha;
	
	public Cuenta(int nC, ArrayList<String> titulares, double saldo, LocalDate fecha) {
		super();
		this.nC = nC;
		this.titulares = titulares;
		this.saldo = saldo;
		this.fecha = fecha;
	}

	public int getnC() {
		return nC;
	}

	public ArrayList<String> getTitulares() {
		return titulares;
	}

	public ArrayList<Tarjeta> getTarjetas() {
		return tarjetas;
	}

	public double getSaldo() {
		return saldo;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	@Override
	public String toString() {
		return "Cuenta [nC=" + nC + ", titulares=" + titulares + ", tarjetas=" + tarjetas + ", saldo=" + saldo
				+ ", fecha=" + fecha + "]";
	}
	
	
	
	
}
