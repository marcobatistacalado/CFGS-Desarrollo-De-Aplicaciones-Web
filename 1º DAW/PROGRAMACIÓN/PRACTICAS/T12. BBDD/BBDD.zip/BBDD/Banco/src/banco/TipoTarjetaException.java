package banco;

public class TipoTarjetaException extends Exception {

	public TipoTarjetaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
