package banco;

public class TarjetaBloqueadaException extends Exception {
    public TarjetaBloqueadaException(String mensaje) {
        super(mensaje);
    }
}

