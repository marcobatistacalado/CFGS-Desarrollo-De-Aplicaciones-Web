package modelos;

import java.time.LocalDate;

public class Movimiento {
	private int nM, tarjeta, cargado;
	private double importe;
	private LocalDate fecha;
	
	public Movimiento(int nM, int tarjeta, int cargado, double importe, LocalDate fecha) {
		super();
		this.nM = nM;
		this.tarjeta = tarjeta;
		this.cargado = cargado;
		this.importe = importe;
		this.fecha = fecha;
	}

	public int getnM() {
		return nM;
	}

	public int getTarjeta() {
		return tarjeta;
	}

	public int getCargado() {
		return cargado;
	}

	public double getImporte() {
		return importe;
	}

	public LocalDate getFecha() {
		return fecha;
	}
}
