package modelos;

import java.time.LocalDate;
import banco.*;

public class Tarjeta{
	private int nT, cuenta;
	private String titular, tipo, clave;
	private double limite;
	private LocalDate caducidad;
	private boolean bloqueada;

	public Tarjeta(int nT, int cuenta, String titular, String tipo, String clave, double limite, LocalDate caducidad,
			boolean bloqueada) throws TipoTarjetaException {
		super();
		if (tipo.equals("C") && !tipo.equals("D")) {
			throw new TipoTarjetaException("Error ese tipo de tarjeta no es válido");
		}
		this.nT = nT;
		this.cuenta = cuenta;
		this.titular = titular;
		this.tipo = tipo; // solo puede ser o C/D
		this.clave = clave;
		if (this.tipo.equals("C")) {
			this.limite = limite;
		}else {
			this.limite = 0;
		}
		this.caducidad = caducidad;
		this.bloqueada = bloqueada;
	}
	
	public boolean retirarDinero(double imp) throws LimiteExcedidoException, TarjetaBloqueadaException, SaldoInsuficienteException {
		if (bloqueada) {
			throw new TarjetaBloqueadaException ("Error la tarjeta está bloqueada");
		}
		if (this.tipo.equals("C")) {
			if (imp>this.limite) {
				throw new LimiteExcedidoException("Error has superado tu límite.");
			}
		}else{
			//que sea mayor que el dinero de la cuenta??????????
			throw new SaldoInsuficienteException("Error has superado tu límite.");
		}
		return true;
	}

	public int getnT() {
		return nT;
	}

	public int getCuenta() {
		return cuenta;
	}

	public String getTitular() {
		return titular;
	}

	public String getTipo() {
		return tipo;
	}

	public String getClave() {
		return clave;
	}

	public double getLimite() {
		return limite;
	}

	public LocalDate getCaducidad() {
		return caducidad;
	}

	public boolean isBloqueada() {
		return bloqueada;
	}
}
