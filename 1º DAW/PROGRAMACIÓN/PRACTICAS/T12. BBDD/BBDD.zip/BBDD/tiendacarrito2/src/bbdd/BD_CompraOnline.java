package bbdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;


import java.time.*;

import modelos.*;
import tiendacarrito.*;

public class BD_CompraOnline extends BD_Conector {

	private static Statement s;
	private static ResultSet reg;

	//Cambiar esto
	public BD_CompraOnline(String file) {
		super(file);
	}

	

}
