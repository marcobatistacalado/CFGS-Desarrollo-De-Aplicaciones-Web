package tiendacarrito;

import java.util.*;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static java.nio.file.StandardOpenOption.*; //Esta línea super importante
import bbdd.*;
import modelos.*;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		BD_CompraOnline bd = new BD_CompraOnline("mysql-properties.xml");
	}

}
