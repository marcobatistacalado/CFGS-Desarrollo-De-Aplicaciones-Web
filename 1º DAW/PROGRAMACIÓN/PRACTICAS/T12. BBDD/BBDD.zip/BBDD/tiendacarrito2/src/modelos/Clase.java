package modelos;

public class Clase {

}
