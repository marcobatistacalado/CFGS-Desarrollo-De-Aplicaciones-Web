package tiendacarrito;

public class InsuficientesUnidadesException extends Exception {

	public InsuficientesUnidadesException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
