package tiendacarrito;

public class ClienteBloqueadoException extends Exception {

	public ClienteBloqueadoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
