package modelos;

public interface Almacenable {
    void vaciar();
    void mostrar();
}
