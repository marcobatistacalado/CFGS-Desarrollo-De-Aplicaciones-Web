package tiendacarrito;

import java.util.*;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import static java.nio.file.StandardOpenOption.*; //Esta línea super importante

import bbdd.*;
import modelos.*;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		BD_CompraOnline bd = new BD_CompraOnline("mysql-properties.xml");
		String codCliente, passwd;
		int opc, menu;
		do {
			System.out.println("1)Log-in  || 2)Salir");
			opc = sc.nextInt();
			sc.nextLine();// Limpiar buffer
			Cliente c1 = logIn(sc, bd);
			System.out.println(c1.toString());

			Carrito carr1 = productosCarrito(bd, c1);
			carr1.mostrar();
			do {
				System.out.println();
				System.out.println("MENU");
				System.out.println("1)Añadir articulo al carrito");
				System.out.println("2)Borrar del carrito nº determinado uds de un producto");
				System.out.println("3)Comprar los productos del carrito-vector");
				System.out.println("4)LogOut");
				System.out.println("5)Cerrar programa");
				menu = sc.nextInt();
				sc.nextLine();// Limpiar buffer
				switch (menu) {
				case 1:
					System.out.println("Introduce cod producto:");
					String codProducto = sc.nextLine();
					if (!validarCodProducto(codProducto)) {
						System.out.println("Codigo de producto erroneo");
						break;
					} else {
						int udsComprar;
						do {
							System.out.println("Nº de unidades");
							udsComprar = sc.nextInt();
							if (udsComprar < 0) {
								System.out.println("Introduce un nº positivo de unidades.");
							}
						} while (udsComprar < 0);

						try {
							int precio = bd.consultarStockProducto(codProducto, udsComprar);
							carr1.add(codProducto, udsComprar, precio);
							System.out.println("Añadido al carrito");
						} catch (ErrorBaseDatos | InsuficientesUnidadesException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}

					break;
				case 2:
					System.out.println("Codigo del producto a borrar:");
					codProducto = sc.nextLine();
					int udsBorrar;
					do {
						System.out.println("Nº de unidades");
						udsBorrar = sc.nextInt();
						if (udsBorrar < 0) {
							System.out.println("Introduce un nº positivo de unidades.");
						}
					} while (udsBorrar < 0);
					if (!carr1.remove(codProducto, udsBorrar)) {
						System.out.println("No tienes ese producto en tu carrito, o no se pueden borrar tantas unidades");
					}else {
						System.out.println("Se ha actualizado tu carrito borrando el producto correspondiente");
					}
					break;
				case 3:
					double importe = c1.Comprar(carr1.getImporteTotal());
					System.out.println("El importe a pagar es de:" + importe);
					
					try {
						if (c1 instanceof ClienteTarjeta)
							bd.actualizar_puntos(((ClienteTarjeta) c1).getPuntos(), carr1.getUsucod());
						bd.actualiz_stock(carr1.getProductos());
						bd.vaciar_carrito(carr1.getUsucod());
					} catch (ErrorBaseDatos e) {
						System.out.println("Avise a sistemas " + e.getMessage());
					}
					carr1.vaciar();
					break;
				case 4:
					try {

						bd.actualiz_carrito(carr1.getProductos(), carr1.getUsucod());
					} catch (ErrorBaseDatos e) {
						System.out.println("Avise a sistemas " + e.getMessage());
					}

					carr1.vaciar();
					break;
				}
			} while (menu != 10);
			

		} while (opc != 2);
	
	}

	// esto se puede hacer sin saber expresiones regulares pero mucho mas largo.
	public static boolean validarCodProducto(String codprod) {
		return codprod.matches("[A-Z]{2,3}[0-9]{2,3}");
	}

	public static Carrito productosCarrito(BD_CompraOnline bd, Cliente c1) {
		try {
			Vector<CarritoUsu> carritoUsu = bd.listaProductosCarrito(c1.getCodCliente());
			Carrito carr1 = new Carrito(carritoUsu, c1.getCodCliente());
			return carr1;
		} catch (ErrorBaseDatos e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return null;
	}

	public static Cliente logIn(Scanner sc, BD_CompraOnline bd) {
		String codCliente;
		String passwd;
		int intentos = 0;
		do {
			System.out.println("Usuario:");
			codCliente = sc.nextLine();
			System.out.println("Password:");
			passwd = sc.nextLine();
			try {
				Cliente c1 = bd.consultarInformacionCliente(codCliente, passwd);
				if (c1 == null) {
					intentos++;
					System.out.println("Usuario/Contraseña incorrectos. Intento: " + intentos);
				} else {
					return c1;
				}
				if (intentos == 3) {
					throw new ClienteBloqueadoException("Bloqueado por 1 minuto");
				}
			} catch (ErrorBaseDatos e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
			} catch (ClienteBloqueadoException e) {
				// TODO Auto-generated catch block
				System.out.println(e.getMessage());
				altaIncidencia(codCliente);
				intentos = 0;
			}
		} while (intentos != 3);
		return null;
	}

	public static void altaIncidencia(String codCliente) {
		Scanner sc = new Scanner(System.in);
		Path file = Paths.get("incidencias.txt");
		Charset charset = Charset.forName("UTF-8");
		BufferedWriter writer = null;

		// Creamos un BufferedWriter de java.io de forma eficiente utilizando Files de
		// java.nio
		try {
			// A�ade informaci�n al final
			writer = Files.newBufferedWriter(file, charset, WRITE, APPEND, CREATE);
			DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/LL/yy" + "-" + "HH:mm:ss");
			writer.write(LocalDateTime.now().format(formato) + " " + codCliente);
			// Escribimos nueva l�nea para separarlas
			writer.newLine();
			writer.close();
			LocalTime horaFinal = LocalTime.now().plusMinutes(1);
			LocalTime horaActual = LocalTime.now();

			while (horaActual.isBefore(horaFinal)) {
				horaActual = LocalTime.now();
			}
			System.out.println("Ya te puedes conectar");
			System.out.println("");

		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					System.err.format("IOException: %s%n", e);
				}
			}
		}
	}

}
