package modelos;

import java.util.Vector;

public class Carrito implements Almacenable {
	private Vector <CarritoUsu> productos;
	private String usucod;
	private double importeTotal;
	private int uds;
	

	public Carrito( Vector<CarritoUsu> productos, String usucod) {
		super();
		int cont = 0;
		double importet=0;
		this.productos = productos;
		
		for(int i =0;i<productos.size();i++) {
			cont++;
			importet +=  productos.get(i).getPrecioud();
		}
		this.uds = cont;
		this.importeTotal = importet;
		this.usucod = usucod;
	}
	
	public void add(String prod, int unidades, double precio) {
		boolean encontrado=false;
		for(int i = 0;i<productos.size();i++) {
			if (productos.get(i).getIdProducto().equals(prod)) {
				productos.get(i).setUnidades((productos.get(i).getUnidades()+unidades));
				this.uds+=unidades;
				this.importeTotal+=unidades*precio;
				encontrado=true;
				break;
			}
		}
		if (!encontrado)
			productos.add(new CarritoUsu(usucod,0,prod,unidades,precio));
	}
	
	public boolean remove(String prod, int unidades) {
		for(int i = 0;i<productos.size();i++) {
			if (productos.get(i).getIdProducto().equals(prod)) {
				if(productos.get(i).getUnidades()<unidades) {
					return false;
				}
				productos.get(i).setUnidades(productos.get(i).getUnidades()-unidades);
				this.uds-=unidades;
				this.importeTotal-=unidades*productos.get(i).getPrecioud();
				return true;
			}
		}
		return false;
	}

	public Vector<CarritoUsu> getProductos() {
		return productos;
	}

	public String getUsucod() {
		return usucod;
	}

	public double getImporteTotal() {
		return importeTotal;
	}

	@Override
	public void vaciar() {
		productos.clear();
		importeTotal = 0;
		uds = 0;
		
	}

	@Override
	public void mostrar() {
		for(int i = 0;i<productos.size();i++) {
			System.out.println(productos.get(i).toString());
		}
		System.out.println("Codigo usuario: "+usucod +" | Importe total: "+importeTotal+" | Unidades total: "+uds);
	}
	
	
}
