package modelos;

public class ClienteNormal extends Cliente {

	public ClienteNormal(String codCliente, String password, String nombre) {
		super(codCliente, password, nombre);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ClienteNormal:"+super.toString();
	}
	
	@Override
	public double Comprar(double importe) {
		if (importe < 100) {
			importe = importe + 7;
		}
		return importe;
	}
	
}
