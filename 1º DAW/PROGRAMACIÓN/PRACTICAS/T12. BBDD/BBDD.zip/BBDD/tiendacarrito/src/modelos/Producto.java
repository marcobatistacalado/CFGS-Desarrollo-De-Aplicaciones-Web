package modelos;

public class Producto {
	private String idP, nombre;
	private int uds;
	private double precioP;
	public Producto(String idP, String nombre, int uds, double precioP) {
		super();
		this.idP = idP;
		this.nombre = nombre;
		this.uds = uds;
		this.precioP = precioP;
	}
	public int getUds() {
		return uds;
	}
	public double getPrecioP() {
		return precioP;
	}
	@Override
	public String toString() {
		return "Producto [idP=" + idP + ", nombre=" + nombre + ", uds=" + uds + ", precioP=" + precioP + "]";
	}
	
}
