package modelos;

public abstract class Cliente {
	private String codCliente, password, nombre;
	
	public Cliente(String codCliente, String password, String nombre) {
		super();
		this.codCliente = codCliente;
		this.password = password;
		this.nombre = nombre;
	}

	public String getCodCliente() {
		return codCliente;
	}

	public String getPassword() {
		return password;
	}

	public String getNombre() {
		return nombre;
	}

	@Override
	public String toString() {
		return "Cliente [codCliente=" + codCliente + ", nombre=" + nombre + "]";
	}
	
	public abstract double Comprar(double importe);

	
}
