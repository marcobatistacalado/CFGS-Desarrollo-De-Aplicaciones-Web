package bbdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;


import java.time.*;

import modelos.*;
import tiendacarrito.*;

public class BD_CompraOnline extends BD_Conector {

	private static Statement s;
	private static ResultSet reg;

	public BD_CompraOnline(String file) {
		super(file);
	}

	public Cliente consultarInformacionCliente(String codCliente, String passwd) throws ErrorBaseDatos, ClienteBloqueadoException {
		String cadenaSQL = "SELECT * FROM clientes WHERE codigousuario = '"+codCliente+"' AND password = '"+passwd+"'";
		Cliente c1 = null;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				//ClienteNormal(String codCliente, String nombre, int tarjeta, int puntos)
				if (reg.getString(4).equals("")) {
					//ClienteNormal(String codCliente, String password, String nombre)
					c1 = new ClienteNormal (reg.getString(1), reg.getString(2), reg.getString(3));
				}else {
					//ClienteTarjeta(String codCliente, String password, String nombre, int tarjeta, int puntos)
					c1 = new ClienteTarjeta (reg.getString(1), reg.getString(2),reg.getString(3), reg.getInt(4), reg.getInt(5));
					
				}
			}
			s.close();
			this.cerrar();
			return c1;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se pude mostrar la información del cliente.");
		}
	}

	public Vector <CarritoUsu> listaProductosCarrito(String codCliente) throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM carrito WHERE codigousuario = '"+codCliente+"'";
		Vector <CarritoUsu> carritoUSu = new Vector <CarritoUsu>();
		String nombre;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				//CarritoUsu(String codusuario, int numero, String idProducto, int unidades, double precioud)
				carritoUSu.add(new CarritoUsu (reg.getString(1), reg.getInt(2), reg.getString(3), reg.getInt(4), reg.getDouble(5)));
			}
			s.close();
			this.cerrar();
			return carritoUSu;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se pude mostrar la información del cliente.");
		}
	}
	
	public int consultarStockProducto(String codProducto, int udsComprar) throws ErrorBaseDatos, InsuficientesUnidadesException {
		String cadenaSQL = "SELECT * FROM productos WHERE idproducto = '"+codProducto+"'";
		int precio=0;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (!reg.next()) {
				throw new InsuficientesUnidadesException ("No existe ese producto");
			}else {
				int stock = reg.getInt(3);
				if (udsComprar > stock) {
					throw new InsuficientesUnidadesException ("No hay suficientes unidades de este producto");
				}
				precio = reg.getInt(4);
			}
			s.close();
			this.cerrar();
			return precio;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se pude mostrar la información del cliente.");
		}
	}
	
	public int actualizar_puntos(int puntos, String codusu) throws ErrorBaseDatos {
		String cadenaSQL = "UPDATE clientes SET puntos = '" + puntos + "' WHERE codigousuario = '" + codusu + "'";
		try {
			this.abrir();
			s = c.createStatement();
			int filas = s.executeUpdate(cadenaSQL);
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos(e.getMessage());

		}
	}
	
	public int actualiz_stock(Vector<CarritoUsu> carritoUsu) throws ErrorBaseDatos {
		int filas = 0;
		String cadenaSQL = "UPDATE productos SET stock = stock - ? WHERE identificador = ?";
		try {
			this.abrir();
			PreparedStatement p = c.prepareStatement(cadenaSQL);
			for (CarritoUsu ca : carritoUsu) {
				p.setInt(1, ca.getUnidades());
				p.setString(2, ca.getIdProducto());
				filas += p.executeUpdate();
			}
			s.close();
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos(e.getMessage());

		}
	}
	
	public void vaciar_carrito(String codUsu) throws ErrorBaseDatos {
		String cadenaSQL = "DELETE FROM carrito WHERE codigousuario = '" + codUsu + "'";
		
		
		try {
			this.abrir();
			s = c.createStatement();
			s.executeUpdate(cadenaSQL);
			s.close();
			
		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos(e.getMessage());

		}
	}
	
public int actualiz_carrito(Vector<CarritoUsu> carritoUsu, String codUsu) throws ErrorBaseDatos {
		
		String cadenaSQL = "INSERT INTO carrito VALUES('" + codUsu + "',?,?,?,?)";
		int cont = 1;
		int filasAfect = 0;
		try {
			this.abrir();
			
			// Insertamos los nuevos elementos del carrito
			PreparedStatement p = c.prepareStatement(cadenaSQL);
			for (CarritoUsu ca : carritoUsu) {
				p.setInt(1, cont);
				cont++;
				p.setString(2, ca.getIdProducto());
				p.setInt(3, ca.getUnidades());
				p.setDouble(4, ca.getPrecioud());

				filasAfect += p.executeUpdate();
			}
			p.close();
			s.close();
			this.cerrar();
			return filasAfect;

		} catch (SQLException e) {
			// System.out.println(e.getMessage());
			throw new ErrorBaseDatos(e.getMessage());

		}
	}

	public String[] arrfcodig() throws ErrorBaseDatos {
		String cadenaSQL = "SELECT identificador from productos";
		try {
			int cont = 0;
			this.abrir();

			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				cont++;

			}
			String[] strg = new String[cont];
			reg.beforeFirst();
			cont = 0;
			while (reg.next()) {
				strg[cont] = reg.getString("identificador");
				cont++;
			}
			s.close();
			this.cerrar();
			return strg;
		} catch (SQLException e) {
			throw new ErrorBaseDatos(e.getMessage());

		}
	}
	
	

}
