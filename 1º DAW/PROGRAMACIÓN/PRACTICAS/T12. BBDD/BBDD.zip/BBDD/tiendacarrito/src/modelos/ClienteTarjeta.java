package modelos;

public class ClienteTarjeta extends Cliente {
	private int puntos, tarjeta;

	public ClienteTarjeta(String codCliente, String password, String nombre, int tarjeta, int puntos) {
		super(codCliente, password, nombre);
		// TODO Auto-generated constructor stub
		this.puntos = puntos;
		this.tarjeta = tarjeta;
	}

	@Override
	public String toString() {
		return super.toString()+"ClienteTarjeta [puntos=" + puntos + ", tarjeta=" + tarjeta + "]";
	}
	
	@Override
	public double Comprar(double importe) {
		puntos+=(importe/20)*3;		
		return importe;
	}

	public int getPuntos() {
		return puntos;
	}

	
	
}
