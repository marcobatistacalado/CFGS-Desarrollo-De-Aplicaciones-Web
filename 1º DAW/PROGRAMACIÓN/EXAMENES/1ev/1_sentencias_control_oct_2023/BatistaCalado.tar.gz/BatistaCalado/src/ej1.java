/*MARCO BATISTA CALADO*/
import java.util.*;
public class ej1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner (System.in);
		double precio = 0;
		
		//GARAJE
		System.out.println("¿Quieres garaje? (s/n)");
		char garaje = sc.nextLine().charAt(0);
		
		if (garaje == 's') {
			precio = 100;
		}else if (garaje == 'n') {
			precio = 75;
		}else {
			System.out.println("Opción de garaje no corecta.");
			System.exit(0);
		}
		
		//PLANTA
		System.out.println("Elija una planta (1-10):");
		int planta = sc.nextInt();
		
		if (planta >= 3 && planta <= 5) {
			precio = precio+5;
		}else if (planta >= 6 && planta <= 9) {
			precio = precio+7;
		}else if (planta == 10) {
			precio = precio+10;
		}else if (planta < 1 || planta > 10) {
			System.out.println("Opción de planta no correcta");
			System.exit(0);
		}
		
		//PUERTA -- en mi caso lo realizo preguntando a todas las plantas su puerta y preguntando la condicion correcta en planta 6.
		System.out.println("Introduce la puerta (A,B,C,D):");
		sc.nextLine();
		char puerta = sc.nextLine().charAt(0);
		if (puerta != 'A' && puerta !=  'B' && puerta != 'C' && puerta != 'D' ) {
			System.out.println("Opción de puerta no correcta");
			System.exit(0);
		}
		if (planta == 6 && (puerta == 'A' || puerta == 'B' )){
			precio = precio+5;
		}
		System.out.println("El precio sin descuentos por día es de: "+precio);
		
		//NOCHES/SEMANAS
		System.out.println("Introduce numero de noches:");
		int noches = sc.nextInt();
		if (noches < 1) {
			System.out.println("Número de noches incorrecto");
			System.exit(0);
		}
		//Descuentos
		double semanas = noches / 7;
		if (semanas >= 2) {
			precio = precio - (precio*0.25);
		}else if (semanas >= 1 && semanas <2 ) {
			if (garaje == 's') {
				precio = precio - (precio*0.2);
			}else if (garaje == 'n') {
				precio = precio - (precio*0.15);
			}
			
		}
		System.out.println("El precio final por día es: "+precio);
		precio = precio * noches;
		System.out.println("El precio total es de: "+precio);
		
		System.out.println("Introduce el día de entrada (L/M/X/J/V/S/D)");
		sc.nextLine();
		char dia = sc.nextLine().charAt(0);
		
		
		switch (dia) {
		case 'L':
			noches = noches % 7 + 1;
			break;
		case 'M':
			noches = noches % 7 + 2;
			break;
		case 'X':
			noches = noches % 7 + 3;
			break;
		case 'J':
			noches = noches % 7 + 4;
			break;
		case 'V':
			noches = noches % 7 + 5;
			break;
		case 'S':
			noches = noches % 7 + 6;
			break;
		case 'D':
			noches = noches % 7 + 7;
			break;
		default:
			System.out.println("NO HAS INTRODUCIDO UN DÍA VÁLIDO");
			System.exit(0);
			break;
		}
		
		System.out.println("Saldrás en");
		switch (noches) {
		case 1:
			System.out.println("Lunes");
			break;
		case 2:
			System.out.println("Martes");
			break;
		case 3:
			System.out.println("Miercoles");
			break;
		case 4:
			System.out.println("Jueves");
			break;
		case 5:
			System.out.println("Viernes");
			break;
		case 6:
			System.out.println("Sabado");
			break;
		case 7:
			System.out.println("Domingo");
			break;
		}
		
		
	}

}
