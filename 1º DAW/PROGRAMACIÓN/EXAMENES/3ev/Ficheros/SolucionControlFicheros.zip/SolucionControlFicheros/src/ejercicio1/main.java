package ejercicio1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import static java.nio.file.StandardOpenOption.*;

public class main {

	public static void main(String[] args) {
		Charset charset = Charset.forName("UTF-8");
		Path auto = Paths.get("auto.txt");
		Path prop = Paths.get("propietario.txt");
		Path log = Paths.get("log.txt");
		BufferedReader readeraut = null;
		BufferedReader readerprop = null;
		BufferedWriter writerlog = null;
		DateTimeFormatter fechaFormateada = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		boolean malfecha = false;
		boolean tienetitural = false;
		ArrayList<Auto> autos = new ArrayList<Auto>();
		LocalDate fechabn = null;

		try {
			readeraut = Files.newBufferedReader(auto, charset);
			String linea = null;
			if (Files.exists(log))
				Files.delete(log);

			while ((linea = readeraut.readLine()) != null) {
				malfecha = false;
				String info[] = linea.split(",");
				String mat = info[0];
				int precio = Integer.parseInt(info[2]);
				String dni = info[3];
				String fecha = info[1];
				try {
					fechabn = LocalDate.parse(fecha, fechaFormateada);
				} catch (DateTimeParseException e) {
					// meter en el log
					// System.out.println("mal fecha");
					writerlog = Files.newBufferedWriter(log, charset, CREATE, WRITE, APPEND);
					writerlog.write("La fecha estaba mal " + mat + " " + fecha);
					writerlog.newLine();
					malfecha = true;
					writerlog.close();
				}
				linea = null;
				if (malfecha == false) {
					readerprop = Files.newBufferedReader(prop, charset);
					tienetitural = false;
					while ((linea = readerprop.readLine()) != null) {
						String datos[] = linea.split(",");
						// System.out.println(dni);
						// System.out.println(datos[0]);
						if (dni.equalsIgnoreCase(datos[0])) {
							String nombre = datos[1].trim();
							String apell = datos[2].trim();
							tienetitural = true;
							// System.out.println(datos[0]);
							autos.add(new Auto(mat, dni, nombre, apell, fechabn, precio));
							break;
						}
					}
					if (tienetitural == false) {
						// System.out.println("sin titular");
						writerlog = Files.newBufferedWriter(log, charset, CREATE, WRITE, APPEND);
						writerlog.write("No tiene propietario " + mat);
						writerlog.newLine();
						writerlog.close();

					}
					readerprop.close();
				}
			}

		} catch (IOException e) {
			System.out.println("error");
		}
		System.out.println(autos);
		System.out.println("--------------------");
		autos.sort(new Ordenado());
		System.out.println(autos);

	}

}
