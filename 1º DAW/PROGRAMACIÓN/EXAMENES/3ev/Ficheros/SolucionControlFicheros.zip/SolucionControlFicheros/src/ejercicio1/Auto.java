package ejercicio1;

import java.time.LocalDate;

public class Auto {
	private String mat,dni,nom,apell;
	private LocalDate fecha;
	private int importe;
	public Auto(String mat, String dni, String nom, String apell, LocalDate fecha, int importe) {
		super();
		this.mat = mat;
		this.dni = dni;
		this.nom = nom;
		this.apell = apell;
		this.fecha = fecha;
		this.importe = importe;
	}
	@Override
	public String toString() {
		return "Auto [mat=" + mat + ", dni=" + dni + ", nom=" + nom + ", apell=" + apell + ", fecha=" + fecha
				+ ", importe=" + importe + "] \n";
	}
	public LocalDate getFecha() {
		return fecha;
	}

	public int getImporte() {
		return importe;
	}

	
	
	
}
