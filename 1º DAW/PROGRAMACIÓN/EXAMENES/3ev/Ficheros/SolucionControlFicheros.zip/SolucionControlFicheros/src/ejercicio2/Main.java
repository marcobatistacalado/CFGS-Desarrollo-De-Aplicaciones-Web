package ejercicio2;

import java.io.IOException;
import java.nio.file.*;
import java.util.HashSet;
import java.util.Scanner;

public class Main {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<String> nombres = new HashSet<>();

		System.out.println("Introduzca el nombre de la primera carpeta: ");
		String ruta1 = sc.nextLine();

		System.out.println("Introduzca el nombre de la segunda carpeta: ");
		String ruta2 = sc.nextLine();

		Path path1 = Paths.get(ruta1);
		Path path2 = Paths.get(ruta2);

		if (!Files.exists(path1) || !Files.exists(path2)) {
			System.out.println("Uno de los archivos no existe!");
			System.exit(0);
		}

		if (!Files.isDirectory(path1) || !Files.isDirectory(path2)) {
			System.out.println("Uno de los archivos no existe!");
			System.exit(0);
		}
		try {
			DirectoryStream<Path> stream1 = Files.newDirectoryStream(path1);
			for (Path path01 : stream1) {
				nombres.add(path01.getFileName().toString());
			}
			stream1.close();

			DirectoryStream<Path> stream2 = Files.newDirectoryStream(path2);
			for (Path path02 : stream2) {
				nombres.add(path02.getFileName().toString());
			}
			stream2.close();

			System.out.println("Archivos en ambos directorios: "+nombres.toString());
			
			System.out.println();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.err.println(e);
		}
	}
}