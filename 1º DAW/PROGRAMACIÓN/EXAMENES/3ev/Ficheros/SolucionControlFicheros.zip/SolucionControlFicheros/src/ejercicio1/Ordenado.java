package ejercicio1;

import java.util.Comparator;



public class Ordenado implements Comparator<Auto>{
	@Override
	public int compare(Auto o1, Auto o2) {
		if (o1.getFecha().isAfter( o2.getFecha()) ) {
			return 1;
		}
		if (o1.getFecha().isBefore(o2.getFecha())) {
			return -1;
			// el que va atras
		}
		if(o1.getImporte() < o2.getImporte()) {
			return -1;
		}
		if(o1.getImporte() > o2.getImporte()) {
			return 1;
		}
		return 0;
		
	}
}
