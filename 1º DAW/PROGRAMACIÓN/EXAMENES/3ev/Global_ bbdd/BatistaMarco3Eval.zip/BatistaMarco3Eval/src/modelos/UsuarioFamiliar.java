package modelos;

public class UsuarioFamiliar extends Usuario {

	
	
	public UsuarioFamiliar(String clave, int pin, String nombre, String apellidos, int numeromiembros,
			double descuento) {
		super(clave, pin, nombre, apellidos, numeromiembros, descuento);
		// TODO Auto-generated constructor stub
		this.descuento = 0;
	}

	@Override
	public double pagar() {
		double total = 0;
		if(this.numeromiembros == 3) {
			total = 30;
		}else if (this.numeromiembros == 4) {
			total = 20;
		}else if (this.numeromiembros >= 4) {
			total = 12;
		}
		return total;
	}
	

}
