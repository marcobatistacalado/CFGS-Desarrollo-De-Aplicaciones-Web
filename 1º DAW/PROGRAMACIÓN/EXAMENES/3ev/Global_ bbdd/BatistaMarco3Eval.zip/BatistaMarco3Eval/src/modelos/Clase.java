package modelos;

public class Clase {
	private String disciplina;
	private int plazas, ocupadas, hora;
	private String codC;
	
	public Clase(String disciplina, int plazas, int ocupadas, int hora, String codC) {
		super();
		this.disciplina = disciplina;
		this.plazas = plazas;
		this.ocupadas = ocupadas;
		this.hora = hora;
		this.codC = codC;
	}
	
}
