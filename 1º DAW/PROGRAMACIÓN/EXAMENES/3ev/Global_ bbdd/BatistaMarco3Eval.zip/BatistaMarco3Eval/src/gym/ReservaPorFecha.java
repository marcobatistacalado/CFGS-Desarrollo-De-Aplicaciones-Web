package gym;

import java.util.Comparator;

import modelos.Reserva;

public class ReservaPorFecha implements Comparator<Reserva> {

	@Override
	public int compare(Reserva arg0, Reserva arg1) {
		// TODO Auto-generated method stub
		int num = arg0.getFecha().compareTo(arg1.getFecha());
		if ( num == 0) {
			return ((Integer)arg1.getPreferente()).compareTo((Integer)arg0.getPreferente());
		}
		return num;
	}

}
