package bbdd;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;

import gym.*;

import java.time.*;

import modelos.*;

public class BD_Gym extends BD_Conector {

	private static Statement s;
	private static ResultSet reg;

	// Cambiar esto
	public BD_Gym(String file) {
		super(file);
	}


	public ArrayList<Usuario> informacionUsuarios() throws ErrorBaseDatos {
		String cadenaSQL = "SELECT * FROM usuarios;";
		ArrayList<Usuario> usuarios = new ArrayList<>();
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			while (reg.next()) {
				// Usuario(String clave, int pin, String nombre, String apellidos, int
				// numeromiembros, double descuento)
				if (reg.getString(5).equals("N")) {
					usuarios.add(new Usuario(reg.getString(1), 0, reg.getString(3), reg.getString(4),
							reg.getInt(6), reg.getDouble(7)));
				} else if (reg.getString(5).equals("F")) {
					usuarios.add(new UsuarioFamiliar(reg.getString(1), 0, reg.getString(3),
							reg.getString(4), reg.getInt(6), 0));
				}
			}

			s.close();
			this.cerrar();
			return usuarios;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se han encontrado usuarios.");
		}
	}

	public boolean existeClase(String codC) throws ErrorBaseDatos, NoExisteUsuarioOClaseException {
		String cadenaSQL = "SELECT * FROM clases WHERE codigo = '" + codC + "'";
		boolean existe = false;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				existe = true;
			}
			if (!existe) {
				throw new NoExisteUsuarioOClaseException("No existe la clase: " + codC);
			}
			s.close();
			this.cerrar();
			return existe;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: no se ha podido comprobar la existencia de la clase.");
		}
	}

	public int añadirReservas(Reserva r) throws ErrorBaseDatos {
		//ESTARÍA PERFECTO EMPLEAR COMMIT Y ROLLBACK PARA QUE O SE EJECUTEN AMBAS O NINGUNA
		String cadenaSQL = "SELECT plazas-ocupadas FROM clases WHERE codigo = '" + r.getCodC() + "';";
		String cadenaSQL2 = "INSERT INTO reservas VALUES(" + 0 + ",'" + r.getCodC() + "','" + r.getUsuario() + "')";
		String cadenaSQL3 = "SELECT ocupadas FROM clases WHERE codigo = '" + r.getCodC() + "';";
		int filas = 0;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				if (reg.getInt(1) > 0) {
					filas = s.executeUpdate(cadenaSQL2);
					reg = s.executeQuery(cadenaSQL3);
					if (reg.next()) {
						int ocupadas = reg.getInt(1)+1;
						if (actualizarNumPlazas (ocupadas, r) == 0) {
							filas = 0;//actualizar numero de plazas
						}
					}

				} else {
					filas = -2; // enviar a cola de espera
				}
			}
			this.cerrar();
			return filas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se puede realizar la reserva");
		}
	}

	public int actualizarNumPlazas(int num, Reserva r) throws ErrorBaseDatos {
		String cadenaSQL = "UPDATE clases SET ocupadas = " + num + " WHERE codigo = '" + r.getCodC()+"'";
		int filas = 0;
		try {
			this.abrir();
			s = c.createStatement();
			filas = s.executeUpdate(cadenaSQL);

			this.cerrar();
			return filas;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBDD: No se puede realizar la reserva");
		}
	}
	
	public ArrayList<Reserva> reservasUsuario(String usuario) throws ErrorBaseDatos, NoExisteUsuarioOClaseException {
		String cadenaSQL = "SELECT * FROM usuarios WHERE clave = '" + usuario + "'";
		String cadenaSQL2 = "SELECT * FROM reservas WHERE usuario = '" + usuario + "'";
		ArrayList <Reserva> reservasUsuario = new ArrayList <Reserva>();
		boolean existe = false;
		try {
			this.abrir();
			s = c.createStatement();
			reg = s.executeQuery(cadenaSQL);
			if (reg.next()) {
				existe = true;
			}
			if (!existe) {
				throw new NoExisteUsuarioOClaseException("No existe el usuario: " + usuario);
			}else {
				reg = s.executeQuery(cadenaSQL2);
				while(reg.next()) {
					//(int numR, String codC, String usuario, LocalDate fecha, int preferente)
					reservasUsuario.add(new Reserva (reg.getInt(1), reg.getString(2), reg.getString(3), null, 0));
				}
			}
			
			s.close();
			this.cerrar();
			return reservasUsuario;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BBBD: no se ha podido hacer la reserva del user.");
		}
	}
	
	public String borrarReserva(int numR) throws ErrorBaseDatos {
		String cadenaSQL = "DELETE from reservas WHERE numero=" + numR + "";
		String cadenaSQL2 = "SELECT codigoclase from reservas WHERE numero ="+numR+"";
		String clase = "";
		int filas = 0;
		try {
			this.abrir();
			Statement s2 = c.createStatement();
			ResultSet reg2 = s2.executeQuery(cadenaSQL2);
			if (reg2.next()) {
				clase = reg2.getString(1);
			}
			s2.close();
			s = c.createStatement();
			filas = s.executeUpdate(cadenaSQL);
			if (filas == 0) {
				clase = "";
			}
			s.close();
			this.cerrar();
			return clase;
		} catch (SQLException e) {
			throw new ErrorBaseDatos("BDDD: No se puede realizar el borrado de la reserva.");
		}
	}

}
