package modelos;

import java.time.LocalDate;

public class Reserva {
	private int numR;
	private String codC, usuario;
	private LocalDate fecha;
	private int preferente;
	
	public Reserva(int numR, String codC, String usuario, LocalDate fecha, int preferente) {
		super();
		this.numR = numR;
		this.codC = codC;
		this.usuario = usuario;
		this.fecha = fecha;
		this.preferente = preferente;
	}

	@Override
	public String toString() {
		return "Reserva [numR=" + numR + ", codC=" + codC + ", usuario=" + usuario + ", fecha=" + fecha
				+ ", preferente=" + preferente + "]";
	}

	public String getCodC() {
		return codC;
	}

	public int getNumR() {
		return numR;
	}

	public String getUsuario() {
		return usuario;
	}

	public LocalDate getFecha() {
		return fecha;
	}

	public int getPreferente() {
		return preferente;
	}
	
	
	
}
