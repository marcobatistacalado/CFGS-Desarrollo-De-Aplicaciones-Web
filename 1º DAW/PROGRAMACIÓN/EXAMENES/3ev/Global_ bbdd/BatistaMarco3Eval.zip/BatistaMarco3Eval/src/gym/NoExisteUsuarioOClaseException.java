package gym;

public class NoExisteUsuarioOClaseException extends Exception {

	public NoExisteUsuarioOClaseException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
