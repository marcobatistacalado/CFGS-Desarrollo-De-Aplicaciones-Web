package gym;

import java.util.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import static java.nio.file.StandardOpenOption.*; //Esta línea super importante
import bbdd.*;
import modelos.*;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		BD_Gym bd = new BD_Gym("mysql-properties.xml");
		LinkedList<Reserva> listaEspera = new LinkedList<Reserva>();

		// EJERCICIO1
		ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
		usuarios = ejercicio1(bd);

		if (usuarios != null) {

			// EJERCICIO2
			listaEspera = ejercicio2(bd, usuarios, listaEspera);
			// EJERCICIO3
			ejercicio3(listaEspera);
			// EJERCICIO4
			listaEspera = ejercicio4(sc, bd, listaEspera);

		}

	}

	private static LinkedList<Reserva> ejercicio4(Scanner sc, BD_Gym bd, LinkedList<Reserva> listaEspera) {
		while (true) {
			System.out.println("Introduce usuario:");
			String usuario = sc.nextLine();

			if (validarUsuario(usuario)) {
				ArrayList<Reserva> reservasUsuario;
				try {
					reservasUsuario = bd.reservasUsuario(usuario);
					if (reservasUsuario.size() == 0) {
						System.out.println("No tiene reservas");
						break; //salir del bucle infinito si no tiene reservas
					} else {
						System.out.println("Reservas del usuario---------------------");
						for (Reserva r : reservasUsuario) {
							System.out.println(r.toString());
						}
						System.out.println("Elige la reserva introduciendo el numero de reserva");
						int numR = sc.nextInt();
						String clase = bd.borrarReserva(numR);
						if (clase.equals("")) {
							System.out.println("No se ha borrado la reserva");
						} else {
							System.out.println("Se ha borrado la reserva");

							for (int i = 0; i < listaEspera.size(); i++) {
								if (listaEspera.get(i).getCodC().equals(clase)) {
									int filas = bd.añadirReservas(listaEspera.get(i));
									if (filas == 0) {
										System.out.println("No se ha podido hacer la reserva para la clase: "
												+ listaEspera.get(i).getCodC());
									} else {
										System.out.println("Reserva realizada de la lista de espera: "
												+ listaEspera.get(i).getCodC());
										listaEspera.remove(listaEspera.get(i)); // borrar de la lista de espera
										break;
									}
								}
							}

						}
					}
				} catch (ErrorBaseDatos | NoExisteUsuarioOClaseException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			} else {
				break; //salir del bucle infinito si el usuario es incorrecto
			}
		}
		return listaEspera;
	}

	public static boolean validarUsuario(String usuario) {
		return usuario.matches("[A-Z]{3}[0-9]{2,3}");
	}

	private static void ejercicio3(LinkedList<Reserva> listaEspera) {
		Collections.sort(listaEspera, new ReservaPorFecha());
		for (Reserva r : listaEspera) {
			System.out.println(r.toString());
		}
	}

	private static LinkedList<Reserva> ejercicio2(BD_Gym bd, ArrayList<Usuario> usuarios,
			LinkedList<Reserva> listaEspera) {
		// EJERCICIO2
		// usuario, clase dirigida, fecha reserva, indicador de reserva preferente -->
		// JLS21,GAP13,18/05/24,1
		Path file = Paths.get("reservas.txt");
		Charset charset = Charset.forName("UTF-8");
		BufferedReader reader = null;
		boolean existeU = true, existeC = true;
		try {
			reader = Files.newBufferedReader(file, charset);
			String line = null;
			while ((line = reader.readLine()) != null) {
				existeU = true;
				existeC = true;
				String lineas[] = line.trim().split(",");
				try {
					existeU = buscarUsuario(usuarios, lineas[0]);
					existeC = bd.existeClase(lineas[1]);
					if (existeU == true && existeC == true) {
						// alta Reservas: (int numR, String codC, String usuario, LocalDate fecha, int
						// preferente)
						Reserva r = crearReserva(lineas);
						int filas = bd.añadirReservas(r);
						if (filas == -2) {
							System.out.println(
									"La clase que se quiere reservar esta llena, procedemos a ponerle en cola: "
											+ r.getCodC());
							// cola
							listaEspera.add(r);
						} else if (filas == 0) {
							System.out.println("No se ha podido hacer la reserva para la clase: " + r.getCodC());
						} else {
							System.out.println("Reserva realizada: " + r.getCodC());
						}

					} else {
						System.out.println(lineas[0]);
						System.out.println(lineas[1]);
					}
				} catch (NoExisteUsuarioOClaseException e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				} catch (ErrorBaseDatos e) {
					// TODO Auto-generated catch block
					System.out.println(e.getMessage());
				}
			}
		} catch (IOException x) {
			System.err.format("IOException: %s%n", x);
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					System.err.format("IOException: %s%n", e);
				}
			}
		}
		return listaEspera;
	}

	private static Reserva crearReserva(String[] lineas) {
		DateTimeFormatter form = DateTimeFormatter.ofPattern("dd/LL/yy");
		LocalDate fcorrecta = LocalDate.parse(lineas[2], form);
		int preferente = Integer.parseInt(lineas[3]);
		Reserva r = new Reserva(0, lineas[1], lineas[0], fcorrecta, preferente);
		return r;
	}

	public static boolean buscarUsuario(ArrayList<Usuario> usuarios, String cod) throws NoExisteUsuarioOClaseException {
		boolean existe = false;
		for (Usuario u : usuarios) {
			if (u.getClave().equals(cod)) {
				existe = true;
			}
		}
		if (!existe) {
			throw new NoExisteUsuarioOClaseException("No existe el usuario: " + cod);
		}
		return existe;
	}

	public static ArrayList<Usuario> ejercicio1(BD_Gym bd) {
		ArrayList<Usuario> usuarios = null;
		System.out.println("USUARIOS---------------------------------");
		try {
			usuarios = bd.informacionUsuarios();
			for (Usuario u : usuarios) {
				System.out.println(u.toString());
				System.out.println("Total a pagar: " + u.pagar());
			}
		} catch (ErrorBaseDatos e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		System.out.println("------------------------------------------");
		return usuarios;
	}

}
