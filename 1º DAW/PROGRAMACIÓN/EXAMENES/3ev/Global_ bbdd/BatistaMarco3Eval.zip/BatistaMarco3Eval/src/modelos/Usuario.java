package modelos;

public class Usuario {
	private String clave;
	private int pin;
	private String nombre, apellidos;
	protected int numeromiembros;
	protected double descuento;
	
	public Usuario(String clave, int pin, String nombre, String apellidos, int numeromiembros,
			double descuento) {
		super();
		this.clave = clave;
		this.pin = pin;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.numeromiembros = numeromiembros;
		this.descuento = descuento;
	}
	
	public double pagar() {
		double total = 0;
		total = 45 - this.descuento;
		return total;
	}

	@Override
	public String toString() {
		return "Usuario [clave=" + clave + ", pin=" + pin + ", nombre=" + nombre + ", apellidos=" + apellidos
				+ ", numeromiembros=" + numeromiembros + ", descuento=" + descuento + "]";
	}

	public String getClave() {
		return clave;
	}
	
	
	
}
