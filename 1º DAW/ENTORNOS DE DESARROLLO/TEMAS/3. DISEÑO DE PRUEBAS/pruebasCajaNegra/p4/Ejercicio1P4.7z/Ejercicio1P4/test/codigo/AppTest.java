package codigo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AppTest {

 //COMPROBACIÓN FUNCIÓN validarNumero con todos los casos de prueba  
    @Test
    public void testValidarNumero_1() { //clase válida
        assertTrue(App.validarNumero(10));
        assertTrue(App.validarNumero(9999));
        assertTrue(App.validarNumero(45));
        assertTrue(App.validarNumero(234));
        assertTrue(App.validarNumero(7662));
    }
    @Test
    public void testValidarNumero_2() { //clase no válida
    	assertFalse(App.validarNumero(9));
        assertFalse(App.validarNumero(4));
    }
    @Test
    public void testValidarNumero_3() { //clase no válida
        assertFalse(App.validarNumero(10000));
        assertFalse(App.validarNumero(345676));
    }
  

    @Test
    public  void testNumeroCifras_1(){
        assertEquals(2, App.numeroCifras(10));
        assertEquals(4, App.numeroCifras(9999));     
        assertEquals(2, App.numeroCifras(45));
        assertEquals(3, App.numeroCifras(234));
        assertEquals(4, App.numeroCifras(7662));
    }

 

	//COMPROBACIÓN FUNCIÓN invertirNumero con todos los casos de prueba
  	@Test
    public void testInvertirNumero_1() { //clase válida
        
       // assertEquals(1, App.invertirNumero(10));
       // assertEquals(9999, App.invertirNumero(9999));
       // assertEquals(54, App.invertirNumero(45));
        assertEquals(432, App.invertirNumero(234));
        assertEquals(2667, App.invertirNumero(7662));
        
    }
             
    @Test
    public void testInvertirNumero_2() { //clase no válida
        assertEquals(-1, App.invertirNumero(9));
        assertEquals(-1, App.invertirNumero(4));
    }
   
    @Test
    public void testInvertirNumero_3() { //clase no válida
        assertEquals(-1, App.invertirNumero(10000));
        assertEquals(-1, App.invertirNumero(345676));
    }
    
       
   
  
}
