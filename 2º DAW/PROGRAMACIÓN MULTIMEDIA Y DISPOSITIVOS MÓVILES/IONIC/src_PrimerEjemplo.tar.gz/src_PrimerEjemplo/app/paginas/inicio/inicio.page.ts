import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.page.html',
  styleUrls: ['./inicio.page.scss'],
  standalone:false
})
export class InicioPage implements OnInit {

  name:string;
  constructor() {
    this.name="Rosa Rodríguez";
   }

  ngOnInit() {
  }

}
