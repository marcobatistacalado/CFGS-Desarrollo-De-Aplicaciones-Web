"""
URL configuration for examen2ev project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from becas import views

urlpatterns = [
    path('', views.Home, name='home'),
    path('solicitar_beca/', views.solicitar_beca, name = 'solicitar_beca'),
    path('ver_beca/', views.ver_beca, name = 'ver_beca'),
    path('info_beca/<str:dni>/', views.info_beca, name = 'info_beca'),
    path('login/', views.login, name = 'login'),
    path('mostrar_lista/', views.mostrar_lista, name = 'mostrar_lista'),
    
]
