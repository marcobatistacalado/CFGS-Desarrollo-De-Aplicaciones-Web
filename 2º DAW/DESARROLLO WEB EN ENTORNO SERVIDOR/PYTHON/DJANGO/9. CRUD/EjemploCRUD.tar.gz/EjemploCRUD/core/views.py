from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views.generic.base import TemplateView

# Create your views here.

class IndexView(TemplateView):
    template_name='core/index.html'
    
    def get(self,request,*args,**kwargs):
        return render(request,self.template_name,{'texto':"Pasando datos"})
    
    def post(self,request,*args,**kwargs):
        return render(request,'acceso_indebido.html')
    
    @method_decorator(csrf_exempt)
    def dispatch(self, *args, **kwargs):
        return super(IndexView, self).dispatch(*args, **kwargs)

        