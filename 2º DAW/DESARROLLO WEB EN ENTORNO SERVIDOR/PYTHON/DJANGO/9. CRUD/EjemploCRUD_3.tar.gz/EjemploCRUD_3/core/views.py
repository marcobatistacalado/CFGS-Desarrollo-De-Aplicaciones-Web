from django.urls import reverse_lazy,reverse
from .forms import ContactForm
from .models import Opinion

from django.views.generic.base import TemplateView
from django.views.generic.edit import FormView,CreateView

# Create your views here.


class HomeView(TemplateView):
    template_name='core/home.html'     
    
class ContactCreate(CreateView):
    model=Opinion
    form_class = ContactForm
    #Hay que indicar dónde vamos en caso de éxito en la operación
    def get_success_url(self):
        return reverse('home')
    
    #O bien 
    """success_url=reverse_lazy('home')
       
    def dispatch(self, request, *args, **kwargs):
        return super(ContactCreate,self).dispatch(request, *args, **kwargs)"""
