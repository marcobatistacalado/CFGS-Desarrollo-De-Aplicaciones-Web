from django.contrib import admin

from core.models import Opinion

# Register your models here.
admin.site.register(Opinion)