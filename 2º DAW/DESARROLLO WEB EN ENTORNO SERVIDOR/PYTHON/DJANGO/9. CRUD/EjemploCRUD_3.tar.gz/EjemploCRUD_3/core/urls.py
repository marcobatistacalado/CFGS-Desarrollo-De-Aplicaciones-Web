from django.urls import path
from .views import ContactCreate,  HomeView

urlpatterns = [
    path('',HomeView.as_view(),name='home'),
    path('contact/',ContactCreate.as_view(),name='contact'),
    
]

