from django import forms
from .models import Opinion

class ContactForm(forms.ModelForm):
    
    class Meta:
        model=Opinion
        fields=['name','content']
        widgets={
            'name': forms.TextInput(attrs={'class':'form-control', 'placeholder':'Introduce Nombre'}),
            'content': forms.Textarea(attrs={'class':'form-control','placeholder':'Danos tu opinión'})
        }

     

