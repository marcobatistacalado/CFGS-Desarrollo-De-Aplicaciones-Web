from django.db import models

# Create your models here.
class Opinion(models.Model):
    name=models.CharField(verbose_name='Nombre',max_length=100)
    content=models.TextField(verbose_name='Mensaje',max_length=500)
    created=models.DateTimeField(auto_now_add=True, verbose_name='Fecha creación')
    updated=models.DateTimeField(auto_now=True,verbose_name='Fecha de modificación')
    
    class Meta:
        verbose_name='opinión'
        verbose_name_plural='opiniones'
        ordering =['name']
        
    def __str__(self):
        return self.name