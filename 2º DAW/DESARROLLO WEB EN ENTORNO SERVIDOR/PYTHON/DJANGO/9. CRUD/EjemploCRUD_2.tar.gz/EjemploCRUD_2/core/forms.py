from django import forms

class ContactForm(forms.Form):
    name = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control', 'placeholder':'Introduce Nombre'}))
    message = forms.CharField(widget = forms.Textarea(attrs={'class':'form-control','placeholder':'Danos tu opinión'}))

    def send_email(self):
        pass


