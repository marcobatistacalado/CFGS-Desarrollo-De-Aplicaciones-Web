from django.views.generic.base import TemplateView
from .forms import ContactForm
from django.views.generic.edit import FormView

# Create your views here.


class HomeView(TemplateView):
    template_name='core/home.html'     
    
class ContactView(FormView):
    template_name = 'core/contact.html'
    form_class = ContactForm
        
    def form_valid(self, form):
        #This method is called when valid form data has been POSTED. It should return an HttpResponse.
        form.send_email()
        return super(ContactView, self).form_valid(form)