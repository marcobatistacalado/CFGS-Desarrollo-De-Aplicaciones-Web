from django.urls import path
from . import views
urlpatterns = [
  
    path('', views.home,name='home'),
    path('login',views.islogin,name='login'),
    path('otra',views.otra,name='otra')
    
    
]
