from django.shortcuts import render
from login.forms import FrmUsuario
from login.models import Usuario

# Create your views here.
def home(request):
    myfrm=FrmUsuario()
    return render(request,'home.html',{'form':myfrm})

def islogin(request):
    if request.POST:
        myfrm=FrmUsuario(request.POST)
        if myfrm.is_valid():
            usuario=myfrm.cleaned_data['usuario']
            password=myfrm.cleaned_data['password']
            try:
                my_usuario=Usuario.objects.get(usuario=usuario)
                request.session['logueado']=my_usuario.usuario
                datos={'email':my_usuario.email,'usuario':usuario}
                return render(request,'detalles.html',datos)
            except Usuario.DoesNotExist:
            
                return render(request,'home.html',{'form':myfrm,'mensaje':'Credenciales no válidas'})
                
            
        
def otra(request):
    usuario=request.session['logueado']
    return render(request,'otra.html',{'usuario':usuario})