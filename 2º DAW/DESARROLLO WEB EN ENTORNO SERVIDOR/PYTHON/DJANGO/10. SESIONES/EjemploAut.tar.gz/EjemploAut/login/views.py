from django.http import HttpResponseRedirect
from django.shortcuts import render
from login.forms import FrmUsuario
from login.models import Usuario
from django.contrib.auth import authenticate,login,logout

# Create your views here.
def home(request):
    myfrm=FrmUsuario()
    return render(request,'home.html',{'form':myfrm})

def islogin(request):
    if request.POST:
        myfrm=FrmUsuario(request.POST)
        if myfrm.is_valid():
            usuario=myfrm.cleaned_data['usuario']
            password=myfrm.cleaned_data['password']
            usu=authenticate(username=usuario,password=password)
            if usu is not None:
                login(request,usu)
                return HttpResponseRedirect("detalles")
            else:    
                return render(request,'home.html',{'form':myfrm,'mensaje':'Credenciales no válidas'})
                
            
def detalles(request):
      if request.user.is_authenticated:
        datos={'usuario':request.user.username,'email':request.user.email}
        return render(request,'detalles.html',datos)   
      else:
            return HttpResponseRedirect("home")      
  
def otra(request):    
        #return render(request,'otra.html',{'usuario':request.user.username}) 
        return render(request,'otra.html')
    
def loginout(request):
    logout(request)
    return HttpResponseRedirect("home")