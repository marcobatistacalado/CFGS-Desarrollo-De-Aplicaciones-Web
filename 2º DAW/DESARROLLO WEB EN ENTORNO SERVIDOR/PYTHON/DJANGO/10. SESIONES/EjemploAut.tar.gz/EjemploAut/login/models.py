from pyexpat import model
from django.db import models

# Create your models here.
class Usuario(models.Model):
    id=models.AutoField(primary_key=True)
    usuario=models.CharField(max_length=16)
    password=models.CharField(max_length=16)
    email=models.EmailField(max_length=80)
    