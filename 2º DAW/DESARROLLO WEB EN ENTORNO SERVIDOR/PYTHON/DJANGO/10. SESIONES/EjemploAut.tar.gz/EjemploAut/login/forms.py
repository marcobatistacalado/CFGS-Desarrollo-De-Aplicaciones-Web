from django import forms

class FrmUsuario(forms.Form):
    usuario=forms.CharField(max_length=16,widget=forms.TextInput(attrs= {'class':'form-control','placeholder':"Tu nombre"}),label="Nombre")
    password=forms.CharField(max_length=16,widget=forms.PasswordInput(attrs={'class':'form-control'}),label="Password")
