from distutils.log import log
from django.urls import path
from . import views


urlpatterns = [
    path('', views.home,name='home'),
    path('home',views.home,name='home'),
    path('login',views.islogin,name='login'),
    path('detalles',views.detalles,name='detalles'),
    path('otra',views.otra,name='otra'),
    path('logout',views.loginout,name='logout'),
    
    
]
