from dataclasses import fields
from enum import unique
from attr import field
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


#A paritr del formulario de creación UserCreation de django, añado el campo email que 
#por defecto no es obligatorio y quito los mensaje de ayuda
class RegistroUsuarioForm(UserCreationForm):
    email=forms.EmailField(max_length=150)
    password1=forms.CharField(min_length=8,widget=forms.PasswordInput,label='Contraseña')
    password2=forms.CharField(min_length=8,widget=forms.PasswordInput,label='Confirma Contaseña')
    
    class Meta:
        model=User
        fields=['username', 'email','password1','password2']
        help_texts={k:"" for k in fields}
