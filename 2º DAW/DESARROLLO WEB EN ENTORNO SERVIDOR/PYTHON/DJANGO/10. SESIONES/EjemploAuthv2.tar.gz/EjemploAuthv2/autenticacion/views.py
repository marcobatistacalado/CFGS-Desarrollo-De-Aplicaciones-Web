from curses.ascii import US
from email import message
from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login,logout

from django.contrib import messages
from autenticacion.forms import RegistroUsuarioForm

# Create your views here.
def home(request):
    return render(request,'home.html')

def registro(request):
    if request.method=='POST':
        #form=UserCreationForm(request.POST) uso su formulario
        #puedo usar el mío, que he generado a partir del suyo
        form=RegistroUsuarioForm(request.POST)
        if form.is_valid():
            form.save()
            #El modelo User de django sólo tiene como campos obligatorios username y password
            #En la bbdd el resto de campos están vacíos. Para cambiar esto, debemos definir
            #un modelo que herede del suyo en el que obliguemos a introducir otros campos
            messages.success(request,'Usuario creado')
            return redirect('home')
           
    else:
        #form=UserCreationForm()
        form=RegistroUsuarioForm()
       
    return render(request,'registro.html',{'form':form})

def home_login(request): #la vista no puede llamarse login pq entra en conflicto con la funcion de django
    if request.method=='POST':
        form=AuthenticationForm(data=request.POST)
        if form.is_valid():
            usu=form.get_user()
            login(request,usu)
            return redirect('home')
    else:
        form=AuthenticationForm()
    return render(request,'login.html',{'form':form})


def loginout(request):
    logout(request)
    return redirect("home")