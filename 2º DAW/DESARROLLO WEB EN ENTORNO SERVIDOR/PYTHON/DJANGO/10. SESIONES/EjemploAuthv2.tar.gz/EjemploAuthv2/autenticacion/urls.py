
from django.urls import path
from . import views



urlpatterns = [
    path('register',views.registro,name='register'), 
    path('', views.home, name='home'),
    path('login',views.home_login,name='login'),
    path('logout',views.loginout,name='logout'),
    
]
