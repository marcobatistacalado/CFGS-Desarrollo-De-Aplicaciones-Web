from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
#Vamos a crear un usuario a partir del objeto User de django pq queremos 
#identificarnos por el email, no por el username
#La tabla de usuarios de django debe estar vacía

#class Usuario(AbstractUser):
 #   email=models.EmailField(max_length=130,unique=True) 
  #  USERNAME_FIELD='email' #para que se logue con email
   # REQUIRED_FIELDS=['username','password'] #para indicar que también son obligatorios
    
#aunque heredamos también el email de User, no es ni único ni obligatorio por defecto
#por eso lo cambiamos.

#tengo que añadir AUTH_USER_MODEL='autenticacion.Usuario' en settings para decirle que use mi
#modelo y no el suyo genérico

