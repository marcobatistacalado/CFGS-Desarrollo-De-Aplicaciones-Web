def procesar_csv_a_diccionario(ruta_csv):
    diccionario_visitas = {}

    with open(ruta_csv, "r", encoding="UTF-8") as archivo:
        lector = archivo.readlines()
        for fila in lector:
            datos = fila.strip().split("|")
            nombre = datos[0]

            if nombre not in diccionario_visitas:
                urls = crearLista(nombre)
                diccionario_visitas[nombre] = urls
    
    return diccionario_visitas

def crearLista(nombre):
    listaUrl = []
    with open("assets/sitios_empleados.csv", "r", encoding="UTF-8") as f:
        lector = f.readlines()
        for fila in lector:
            if fila.startswith(nombre):
                url = (fila[:-1]).split("|")[1]
                if url not in listaUrl:
                    listaUrl.append(url)
        return listaUrl

def mostrarInfo(diccionario):
    for clave, valor in diccionario.items():
        print(str(clave)+" : "+str(valor))

def listaSitiosTrabajo(ruta):
    listaSitios = []
    with open(ruta, "r", encoding="UTF-8") as f:
        lector = f.readlines()
        for fila in lector:
            listaSitios.append(fila[:-1])
    return listaSitios

def mostrarMinutos(cad):
    with open("assets/sitios_empleados.csv", "r", encoding="UTF-8") as f:
        lector = f.readlines()
        for fila in lector:
            if fila.startswith(cad):
                return (fila[:-1]).split("|")[2]

