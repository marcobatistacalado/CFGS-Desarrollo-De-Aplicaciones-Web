import csv
import funciones.modulos as func

#APARTADO 1
print("APARTADO 1")
diccionario_visitas = func.procesar_csv_a_diccionario("assets/sitios_empleados.csv")
                
func.mostrarInfo(diccionario_visitas)

#APARTADO 2A
print("-"*100)
print("APARTADO2")
listaSitios = func.listaSitiosTrabajo("assets/sitios_trabajo.txt")


#APARTADO2B:
filtrados = []
for clave, valor in diccionario_visitas.items():
    filtrado = list(filter(lambda x : x not in listaSitios, valor))
    if len(filtrado)!=0:
        print(clave)

print("-"*100)
#APARTADO3
print("APARTADO3")
diccionario_3 = {
}

for clave, valor in diccionario_visitas.items():
    diccionario_3[clave] = []
    tiene = False
    for url in valor:
        if url not in listaSitios:
            tiene = True
            cad = (clave+"|"+str(url))
            minutos = func.mostrarMinutos(cad)
            listaUrl_Minutos = [url, minutos]
            diccionario_3[clave].append(listaUrl_Minutos)
    if tiene == False:
        del(diccionario_3[clave])
    
func.mostrarInfo(diccionario_3)
