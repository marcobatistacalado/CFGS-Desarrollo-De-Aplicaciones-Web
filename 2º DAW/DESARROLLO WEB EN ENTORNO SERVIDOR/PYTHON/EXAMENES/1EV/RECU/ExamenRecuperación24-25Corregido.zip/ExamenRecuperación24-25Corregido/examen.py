from funciones import utilidades

ruta="assets/charlas.json"

datos=utilidades.get_datos(ruta)

n=30
dicc_aforo=utilidades.get_charlas_aforo(datos,n)
print(dicc_aforo)

charla="El internet de los datos"
n=2
utilidades.venta_entradas(charla,n,datos)
print(datos)



utilidades.generar_csv(datos)