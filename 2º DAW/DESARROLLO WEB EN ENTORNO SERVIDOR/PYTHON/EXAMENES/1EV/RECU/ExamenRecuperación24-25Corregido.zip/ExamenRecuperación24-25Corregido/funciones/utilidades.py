import json
import csv

def get_datos(ruta):
    fichero=open(ruta)
    datos=json.load(fichero)
    fichero.close()
    return datos


def get_charlas_aforo(datos,n):
    dicc={}
    for s in datos:
        aforo=s["aforo"]
        per=aforo*n/100
        l=list(filter(lambda c: int(c["entradasvendidas"])< per,s["charlas"]))
        if (len(l)>0):
            numero=s["numero_sala"]
            dicc[numero]=l
    return dicc

def venta_entradas(charla,numero,datos):
    for s in datos:
        l=list(filter(lambda c: c["tema"]==charla,s["charlas"]))
        if (len(l)>0):
            obj=l[0]
            obj["entradasvendidas"]+=numero
            s["recaudacion"]+=numero*obj["precio"]
            
    
def generar_csv(datos):
    fichero=open("assets/recaudacion.csv","w")
    f=csv.writer(fichero)
    for s in datos:
        row=[s["numero_sala"],  len(s["charlas"]),s["recaudacion"]]
        f.writerow(row)
    fichero.close()
        
