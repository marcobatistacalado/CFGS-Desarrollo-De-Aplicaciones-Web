

def get_datos(ruta):
    


def get_charlas_aforo(datos,porcentaje):
    

def venta_entradas(charla,numero,datos):
    
            
    
def generar_csv(datos):
    
        
