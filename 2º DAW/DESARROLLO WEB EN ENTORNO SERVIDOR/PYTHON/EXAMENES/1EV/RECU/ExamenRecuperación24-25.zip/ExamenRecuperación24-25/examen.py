from funciones import utilidades

ruta="assets/charlas.json"




