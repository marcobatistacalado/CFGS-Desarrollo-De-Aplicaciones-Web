import csv
import funciones.modulos as func

#APARTADO 1
print("APARTADO 1")
diccionarioVisitas = {}
with open("assets/sitios_empleados.csv", "r", encoding="UTF-8") as f:
        lector = f.readlines()
        for fila in lector:
            nombre = (str(fila[:-1]).split("|")[0])
            if (nombre) not in diccionarioVisitas:
                URL = func.crearLista(nombre)
                diccionarioVisitas[nombre] = URL
                
func.mostrarInfo(diccionarioVisitas)

#APARTADO 2A
print("-"*100)
print("APARTADO2")
listaSitios = func.listaSitiosTrabajo("assets/sitios_trabajo.txt")


#APARTADO2B:
filtrados = []
for clave, valor in diccionarioVisitas.items():
    filtrado = list(filter(lambda x : x not in listaSitios, valor))
    if len(filtrado)!=0:
        print(clave)

print("-"*100)
#APARTADO3
print("APARTADO3")
diccionario_3 = {
}

for clave, valor in diccionarioVisitas.items():
    diccionario_3[clave] = []
    tiene = False
    for url in valor:
        if url not in listaSitios:
            tiene = True
            cad = (clave+"|"+str(url))
            minutos = func.mostrarMinutos(cad)
            listaUrl_Minutos = [url, minutos]
            diccionario_3[clave].append(listaUrl_Minutos)
    if tiene == False:
        del(diccionario_3[clave])
    
func.mostrarInfo(diccionario_3)
