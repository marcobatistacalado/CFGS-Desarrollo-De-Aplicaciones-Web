def crearLista(nombre):
    listaUrl = []
    with open("assets/sitios_empleados.csv", "r", encoding="UTF-8") as f:
        lector = f.readlines()
        for fila in lector:
            if fila.startswith(nombre):
                url = (fila[:-1]).split("|")[1]
                if url not in listaUrl:
                    listaUrl.append(url)
        return listaUrl

def mostrarInfo(diccionario):
    for clave, valor in diccionario.items():
        print(str(clave)+" : "+str(valor))

def listaSitiosTrabajo(ruta):
    listaSitios = []
    with open(ruta, "r", encoding="UTF-8") as f:
        lector = f.readlines()
        for fila in lector:
            listaSitios.append(fila[:-1])
    return listaSitios

def mostrarMinutos(cad):
    with open("assets/sitios_empleados.csv", "r", encoding="UTF-8") as f:
        lector = f.readlines()
        for fila in lector:
            if fila.startswith(cad):
                return (fila[:-1]).split("|")[2]

