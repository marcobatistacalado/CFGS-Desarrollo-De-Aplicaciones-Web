﻿using static marcoBatista.Models.Enumerados;

namespace marcoBatista.Models
{
    public class Alumno : Usuario
    {
        public EnumeradoCiclo Ciclo { get; set; }
        public int Curso { get; set; } //1 oo 2
        public List<string> Idiomas { get; set; }
    }
}
