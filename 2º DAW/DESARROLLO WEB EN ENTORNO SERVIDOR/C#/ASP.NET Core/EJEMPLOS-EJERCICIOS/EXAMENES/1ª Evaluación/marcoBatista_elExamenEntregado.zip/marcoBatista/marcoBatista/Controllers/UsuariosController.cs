﻿using marcoBatista.Interfaces;
using marcoBatista.Models;
using Microsoft.AspNetCore.Mvc;

namespace marcoBatista.Controllers
{
    public class UsuariosController : Controller
    {
        private readonly IRepositorioUsuarios repositorioUsuarios;

        public UsuariosController(IRepositorioUsuarios x)
        {
            this.repositorioUsuarios = x;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string nick, string contrasenna)
        {
            var usuario = repositorioUsuarios.IsUsuario(nick, contrasenna);
            if (usuario == null)
            {
                ViewBag.Error = "Usuario no encontrado / contraseña incorrecta";//mensaje de error
                return View("Login"); 
            }
            if (usuario is Alumno alumno)
            {
                return View("Alumno", alumno);
            }
            else if (usuario is Profesor)
            {
                var alumnos = repositorioUsuarios.GetAlumnos();
                return View("Profesor", alumnos);
            }
            ViewBag.Error = "Tipo de usuario desconocido.";
            return View("Login");
        }

        public IActionResult Registro()
        {
            return View("Registro");
        }

        [HttpPost]
        public IActionResult Registro(Alumno nuevoAlumno)
        {
            if (repositorioUsuarios.IsRepetido(nuevoAlumno.Nick, nuevoAlumno.Contrasenna))
            {
                ViewBag.Error = "usuario/contraseña ya existen";//mensaje de error
                return View("Registro");
            }
            repositorioUsuarios.AltaUsuario(nuevoAlumno);
            return RedirectToAction("Login"); //prg 
        }

        public IActionResult Editar(string id)
        {
            //var usuario = repositorioUsuarios.IsUsuario(id);
            return View("Editar", id);
        }

        [HttpPost]
        public IActionResult Editar(String Contrasenna, String ConfirmarContrasenna, String id)
        {
            if (Contrasenna != ConfirmarContrasenna)
            {
                ViewBag.Error = "Contraseñas no son iguales";//mensaje de error
                return View();
            }
            repositorioUsuarios.CambioContrasenna(id, Contrasenna);
                return RedirectToAction("Login"); //prg
        }
    }
}
