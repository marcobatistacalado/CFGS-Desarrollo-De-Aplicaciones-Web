﻿using static marcoBatista.Models.Enumerados;

namespace marcoBatista.Models
{
    public class Profesor : Usuario
    {
        public EnumeradoEspecialidad Especialidad { get; set; }
    }

}
