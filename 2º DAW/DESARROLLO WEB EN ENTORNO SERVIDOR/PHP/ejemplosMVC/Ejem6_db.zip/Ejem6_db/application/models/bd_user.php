<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class BD_User extends CI_Model{
    
    
   public function isUsuario($user){            
    $u=$this->db->escape($user->getUser());
    $p=$this->db->escape($user->getPass());
       //No es necesario incluir las comillas simples por las pone la función escape
    $cadenaSQL="SELECT * from usuarios where usuario=".$u ." and password=".$p;   
    $registros=$this->db->query($cadenaSQL);        
    return $registros->num_rows();
        
      /*  $this->db->select('*');
        $this->db->from('usuarios');
        $this->db->where('usuario',$user);
        $this->db->where('password',$pass);
        $query=$this->db->get();
        if ($query->num_rows()==1)
            return true;
        return false;*/
    }
}
    

?>
