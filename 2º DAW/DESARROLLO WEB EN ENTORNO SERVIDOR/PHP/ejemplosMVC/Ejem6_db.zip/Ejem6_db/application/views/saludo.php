
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1> Hola, mi usuario es <?php echo $user; ?> </h1>
   <br>Este es mi primer acceso a base de datos
</body>
</html>