<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
        $this->load->helper('form');
    }
    
    public function index(){
        $this->load->view('login');
    }
    
    public function isLogin(){
        $this->load->model('user');
        $this->load->model('bd_user');
        
        $usu=$this->input->post('nombre');
        $pass=$this->input->post('password');
        
        $user=new User();
        $user->init_entry($usu,$pass);
        
        $bdUser=new BD_User();
        if ($bdUser->isUsuario($user)){       
            $data['user']=$usu;
            $this->load->view('saludo',$data);
            
        }
        else{                     
              $data['error']='usuario no válido';
              $this->load->view('login',$data);
        }
            
        
    }
}

?>