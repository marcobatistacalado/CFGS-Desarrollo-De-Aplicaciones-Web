<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Home extends CI_Controller
{
 
	public function index()
	{
		$username = "rrodriguez";
		$password = "a1234567.";
		$register = date("Y-m-d");
		$this->load->model('aes_model');
		$this->aes_model->save($username,$password,$register);
       
	}
 
	public function get()
	{
		$this->load->model('aes_model');
		$users = $this->aes_model->get();
		foreach($users as $user)
		{
			echo $user->username. "---" . $user->password . "----" . $user->register_date . "<br>";
		}
	}
 
}
 
