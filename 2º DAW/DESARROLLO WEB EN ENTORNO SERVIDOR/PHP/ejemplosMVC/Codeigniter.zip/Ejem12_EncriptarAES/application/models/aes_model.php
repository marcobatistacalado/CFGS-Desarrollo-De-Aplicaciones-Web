<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Aes_model extends CI_Model 
{
	public $keycrypt;
	public function __construct()
	{
		parent::__construct();
		$this->keycrypt = $this->config->item("aes_encryption_mykey");
	}
 
	public function save($username,$password,$register)
	{
		$user = $this->db->escape($username);
		$pass = $this->db->escape($password);
		$date = $this->db->escape($register);
		$this->db->set('username', openssl_encrypt($user,"aes-256-cbc",$this->keycrypt));
		$this->db->set('password', openssl_encrypt($pass,"aes-256-cbc",$this->keycrypt));
		$this->db->set('register_date',$date, FALSE);
		$this->db->insert("users");
       
	}	
 
	
}
 
