<?php

$password="a1234567";
echo "<h3>ALGORITMOS POCO SEGUROS</h3>";
echo "md5 - ".md5($password)."<br>";
echo "sha1 - ".sha1($password)."<br>";
echo "<hr><br>";
echo "<h3>ALGORITMOS QUE PUEDE UTILIZAR UNA FUNCIÓN HASH</h3>";
foreach(hash_algos() as $algoritmo)
	echo $algoritmo. " - ";
echo "<hr><br>";
echo "<h3>ALGORITMOS QUE PUEDE UTILIZAR UNA FUNCIÓN HASH</h3>";
foreach(hash_algos( ) as $algoritmo)
	echo hash($algoritmo, $password)."<br>";
echo "<hr><br>";

$enc=password_hash($password,PASSWORD_DEFAULT,10);
if (password_verify($enc,$password))
    echo "clave válida";
else
    echo "clave inválida";

?>