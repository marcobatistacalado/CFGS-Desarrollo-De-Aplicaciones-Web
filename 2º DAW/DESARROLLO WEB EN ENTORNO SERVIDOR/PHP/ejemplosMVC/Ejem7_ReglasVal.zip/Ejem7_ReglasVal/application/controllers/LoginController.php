<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class LoginController extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
        $this->load->helper('form');
        $this->load->library('form_validation');
    }
    
    public function index(){
        $this->load->view('login');
    }
    
    public function isLogin(){
        $this->load->model('user');
        $this->load->model('bd_user');
        
        $this->form_validation->set_rules("nombre", "Nombre","required");
        $this->form_validation->set_rules("password","Password","required|min_length[8]");
        $this->form_validation->set_message('required', 'El campo %s es obligatorio');
        $this->form_validation->set_message('min_length', 'El Campo %s debe tener un mínimo de %d Caracteres');
        
        if ($this->form_validation->run()){
            $usu=$this->input->post('nombre');
            $pass=$this->input->post('password');
        
            $user=new User();
            $user->init_entry($usu,$pass);
        
            $bdUser=new BD_User();
            if ($bdUser->isUsuario($user)){       
                $data['user']=$usu;
                $this->load->view('saludo',$data);            
            }
            else{                     
              $data['error']='usuario no válido';
              $this->load->view('login',$data);
            }
        }
        else
             $this->load->view('login');
            
        
    }
}

?>