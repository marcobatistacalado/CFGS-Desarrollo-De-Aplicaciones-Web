<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class BD_User extends CI_Model{
    
    
   public function isUsuario($user){            
    
        
      $this->db->select('*');
        $this->db->from('datos');
        $this->db->where('usuario',$user->getUser());
        $this->db->where('password',$user->getPass());
        $query=$this->db->get();
        if ($query->num_rows()==1)
            return true;
        return false;
    }
}
    

?>
