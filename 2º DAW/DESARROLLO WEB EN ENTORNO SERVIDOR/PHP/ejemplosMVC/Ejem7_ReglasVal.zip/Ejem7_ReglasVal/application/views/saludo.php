
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1> Hola, mi usuario es <?php echo $user; ?> </h1>
   <br>Esta es mi primera vista
</body>
</html>