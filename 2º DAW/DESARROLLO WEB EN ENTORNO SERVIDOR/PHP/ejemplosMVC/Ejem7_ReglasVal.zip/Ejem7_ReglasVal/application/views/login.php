<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="StyleSheet" href="<?=base_url();?>css/estilos.css" type="text/css" />



</head>
<body>
<div id="titulo">
EJEMPLO BBDD CODEIGNITER
</div>
<hr />
<div id="caja">

<br />
<?php echo form_open('loginController/isLogin'); ?>
<h1>Login</h1>
<br />
<?php echo validation_errors(); ?>
  <p>
    <label>Nombre<span class="peque">Introduce nombre</span></label>
    <input type="text" name="nombre" id="nombre" class="campo"  value='<?php echo set_value("nombre")?>' /><br>
       <?php echo form_error("nombre"); ?><br>
       
    <label>Password<span class="peque">Introduce tu clave</span></label>
    <input type="password" name="password" id="password" class="campo" /><br>
     
      <?php echo form_error("password"); ?>
    </p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
  <p>&nbsp;</p>

  <div id="registrar">
    <p>&nbsp;</p>
      <center> <button type="submit">Registrar</button> </center>
   
    </div>

 <?php if (isset($error))
       echo $error;
echo form_close(); ?>
    </div>
</body>
</html>






