<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
 <form action='<?php echo base_url()."index.php/Inicio/comprobar"?>' method="post">
    <input type="text" name="nombre">
    <input type="submit" name="aceptar" value="Pulsa">
    </form>
</body>
</html>