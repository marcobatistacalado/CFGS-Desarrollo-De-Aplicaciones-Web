<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Inicio extends CI_Controller{
    
    public function __construct(){
        parent::__construct();
     
    }
    
    public function index(){
       $this->load->helper('url');
        $this->load->view('login');
    }
    
    public function comprobar(){
     
       $datos['nombre']=$this->input->post('nombre',TRUE);
       $this->load->view('saludo',$datos);
    }
}

?>