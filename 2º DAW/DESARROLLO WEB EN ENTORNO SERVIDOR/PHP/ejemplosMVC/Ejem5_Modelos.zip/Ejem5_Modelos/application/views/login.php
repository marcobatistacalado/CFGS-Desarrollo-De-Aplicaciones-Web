<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <link rel="StyleSheet" href="<?=base_url();?>css/estilos.css" type="text/css" />
</head>
<body>
  
   <?php $data=array('class'=>'contacto');echo form_open("CI_Login/login",$data); ?>  
   <p>Login<p>
    <label>Introduce nombre</label>
   <?php echo form_input("user") ."<br>"; ?>
    <label>Introduce password</label>   
   <?php echo form_password("pass")."<br>"; 
    echo "<br><center>". form_submit("Aceptar","Aceptar") . "</center>";
    echo form_close();
    ?>
  
</body>
</html>