<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class CI_Login extends CI_Controller {
    
    public function __construct(){
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model("User");
    }
    
    public function index(){
        $this->load->view("login");
    }
    
    public function login(){
        $u=$this->input->post('user');
        $p=$this->input->post('pass');
        
        $user=new User();
        $user->init_entry($u,$p);       
        if ($user->isUser()){
             $data['user']=$user->getUser();
            $this->load->view('saludo',$data);
        }
        else            
            $this->load->view('login');
        
        
    }
}
?>