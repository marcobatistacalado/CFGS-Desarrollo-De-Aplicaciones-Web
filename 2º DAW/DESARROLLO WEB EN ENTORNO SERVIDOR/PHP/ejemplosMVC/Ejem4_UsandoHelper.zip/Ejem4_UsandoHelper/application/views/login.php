<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link href='<?php echo base_url()?>/css/estilos.css' type="text/css" rel="stylesheet">
</head>
<body>
    <div>
       <?php 
        $data=array('class'=>'contacto');
        echo form_open('Inicio/comprobar',$data); ?>
       
            <div><label>Tu Nombre:</label><input type='text' value='' name="nombre"></div>
            <div><input type='submit' value='Envia Nombre' name="enviar"></div>
       <?php echo form_close();?>
    </div>
</body>
</html>