
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <h1> Hola, mi nombre es <?php echo $nombre; ?> </h1>
   <br>Esta es mi primera vista
</body>
</html>