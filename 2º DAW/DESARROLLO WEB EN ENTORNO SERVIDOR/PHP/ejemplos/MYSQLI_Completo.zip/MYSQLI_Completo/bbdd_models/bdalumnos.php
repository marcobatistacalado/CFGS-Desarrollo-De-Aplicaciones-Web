<?php
 include_once ("bbdd.php");
 include_once($_SERVER['DOCUMENT_ROOT']."/MYSQLI_Completo/models/alumno.php");

class BD_Alumnos extends BD_MYSQLI{
   

function listar_todos(){
$lista=array();
$this->open_connection();
$this->registros=$this->conn->query("SELECT * FROM alumnos"); 
$this->close_connection();  
while ( $fila=mysqli_fetch_array($this->registros) )	
    array_push($lista,new Alumno($fila['nombre'],$fila['nota'],$fila['curso'],$fila['codigo']));

return $lista;
}

function listar_curso($curso){
$lista=array();
$this->open_connection();
$curso=$this->conn->real_escape_string($curso);
$this->registros=$this->conn->query("SELECT * FROM alumnos WHERE curso='$curso'");
$this->close_connection();
while ( $fila=mysqli_fetch_array($this->registros) )	
    array_push($lista,new Alumno($fila['nombre'],$fila['nota'],$curso,$fila['codigo']));

return $lista;
}

function anyadir($alumno){
$this->open_connection();
$nombre=$this->conn->real_escape_string($alumno->getNombre());
$curso=$this->conn->real_escape_string($alumno->getCurso());
$nota=$this->conn->real_escape_string($alumno->getNota());
$cadenaSQL="INSERT INTO alumnos(nombre,curso,nota) VALUES('".$nombre ."','". $curso."',".$nota.")";
$this->conn->query($cadenaSQL); 
$f=$this->conn->affected_rows;
$this->close_connection();   
return $f;
}

function eliminar($codigo){
$this->open_connection();
$codigo= $this->conn->real_escape_string($codigo);   
$this->conn->query("DELETE FROM alumnos WHERE codigo=$codigo");
$f=$this->conn->affected_rows;
$this->close_connection();   
return $f;
}

function modificar($codigo, $nota){
$this->open_connection();
$codigo= $this->conn->real_escape_string($codigo);   
$nota=$this->conn->real_escape_string($nota);    
$this->conn->query("UPDATE alumnos set nota=$nota WHERE codigo=$codigo");
$f=$this->conn->affected_rows;
$this->close_connection();   
return $f;
}
    
function buscarAlumno($codigo){
$alumno=null;
$this->open_connection();
$codigo= $this->conn->real_escape_string($codigo);  
$this->registros=$this->conn->query("SELECT * FROM alumnos WHERE codigo=$codigo");    
if ($fila=mysqli_fetch_array($this->registros) )
    $alumno=new Alumno($fila['nombre'],$fila['nota'],$fila['curso'],$fila['codigo']);	
$this->close_connection();  
return $alumno;
}
}
?>