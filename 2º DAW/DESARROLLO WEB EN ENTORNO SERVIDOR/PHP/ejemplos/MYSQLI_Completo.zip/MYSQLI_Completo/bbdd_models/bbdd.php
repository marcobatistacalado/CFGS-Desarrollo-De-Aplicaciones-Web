<?php
include ($_SERVER['DOCUMENT_ROOT']."/MYSQLI_Completo/config/config.php");

abstract class BD_MYSQLI {
protected $conn;
protected $registros;

public function open_connection() {
$this->conn=new mysqli(DB_HOST, DB_USER, DB_PASS,DB_NAME);
if ($this->conn->connect_error) 
    die('Fallo la conexion: '. $mysqli->connect_error);
$this->conn->set_charset(DB_CHARSET);
}

public function close_connection() {
$this->conn->close();

}
}
?>