<?php
class Alumno{
    private $nombre;
    private $nota;
    private $curso;
    private $codigo;
    
public function __construct ($nombre,$nota,$curso,$codigo=0)
 {
     $this->nombre=$nombre;
     $this->nota=$nota;
     $this->curso=$curso;
     $this->codigo=$codigo;  
 }
    
public function getNombre(){
     return $this->nombre;
}

public function getNota(){
    return $this->nota;
}

public function getCodigo(){
    return $this->codigo;
}
    
public function getCurso(){
        return $this->curso;
    }
    
}

?>