<?php
define("DB_HOST", "localhost");
define ("DB_USER", 'daw2');
define("DB_PASS", '2daw2');
define("DB_NAME",'colegio');
define ("DB_CHARSET", 'UTF8');

?>