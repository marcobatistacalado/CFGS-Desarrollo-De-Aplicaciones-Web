
<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Document</title>

</head>

<body>

    <form action="controller/operaciones.php" method="post">
			<h1 align="center">Elige operación</h1>
			<table border="1" align="center">
				<tr><td>
					<input type="radio" name="accion" value="insertar">Insertar alumno
				</td></tr>
				<tr><td>
					<input type="radio" name="accion" value="eliminar">Eliminar alumno
				</td></tr>
				<tr><td>
					<input type="radio" name="accion" value="modificar">Modificar nota alumno
				</td></tr>
				<tr><td>
					<input type="radio" name="accion" value="verTodos">Consultar alumnos
				</td></tr>
				<tr><td>
					<input type="radio" name="accion" value="alumnosCurso">Consultar alumnos de un curso
				</td>	
				<td>
					Cursos <select name="curso">
									<option>DAW</option>											
									<option>ASIR</option>		
									<option>FIN</option>		
									
								</select> 
				<td></tr>
			</table>		
			<p align="center"><input type="submit" name="acept" value="Aceptar"> </p>
        </form>



</body>

</html>

