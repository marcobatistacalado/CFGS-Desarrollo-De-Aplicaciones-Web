<?php 
 include_once ($_SERVER['DOCUMENT_ROOT']."/MYSQLI_Completo/bbdd_models/bdalumnos.php");
 $bdAl=new BD_alumnos();
	$alumno=$bdAl->buscarAlumno($_POST['codigo']);              
	if ($alumno==null)
	    echo "no existe ese alumno";
	else{
  ?>
    <!DOCTYPE html>
    <html lang="en">
                    <head>
                        <meta charset="UTF-8">
                        <title>Document</title>
                    </head>
                    <body>
                        <form action="modificar.php" method="post">
				        <p>Nombre: <input type="text" name="nombre" value='<?php echo $alumno->getNombre()?>'> </p>
				        <p>Nota: <input type="text" name="nota" value='<?php echo $alumno->getNota()?>'> </p>
				        <p>Nueva Nota: <input type="text" name="notaNueva" > </p>
				        <p><input type="submit" name="cambiar" value="cambiar"> 
				        <input type="button" value="Cancelar" onClick="location.href='../index.php' "></p>
				        <input type="hidden" name="codigo" value='<?php echo $alumno->getCodigo()?>'>				        
				        </form>
                    </body>
                    </html>
    <?php } ?>