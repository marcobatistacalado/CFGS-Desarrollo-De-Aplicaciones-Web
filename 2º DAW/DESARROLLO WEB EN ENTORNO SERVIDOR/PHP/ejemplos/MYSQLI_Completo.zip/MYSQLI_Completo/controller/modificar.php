<?php      
    include_once ($_SERVER['DOCUMENT_ROOT']."/MYSQLI_Completo/bbdd_models/bdalumnos.php");
    $bdAl=new BD_alumnos();
    if ( isset($_POST['cambiar'])){            
            if ( $bdAl->modificar($_POST['codigo'],$_POST['notaNueva'])==0)				
					echo "no se ha podido modificar alumno";
			else
					header('Location: ../index.php');
	}
	
			 
    else
            header('Location: ../index.php');
        ?>