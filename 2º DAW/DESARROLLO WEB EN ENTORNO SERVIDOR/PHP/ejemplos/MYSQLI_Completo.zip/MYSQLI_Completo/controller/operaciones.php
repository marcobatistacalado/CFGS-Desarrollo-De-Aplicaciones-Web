<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
</head>
<body>
 
<?php
 if (!isset($_POST['accion']))
      header('Location: http://localhost/MYSQLI_Completo');
 else{
     switch ($_POST['accion'])
     {
         case 'verTodos': header("Location: todos.php");break;	
         case 'alumnosCurso': header("Location: curso.php?curso=".$_POST['curso']);break;
		 case 'insertar': header("Location: ../views/add_view.php");break;
         case 'eliminar': header("Location: eliminar.php");break;
         case 'modificar':header("Location: ../views/buscar_view.php");break;		
     }
    }
 
?>
</body>
</html>