<?php
  if ( isset($_POST['registrar'])){
            include_once($_SERVER['DOCUMENT_ROOT']."/MYSQLI_Completo/models/alumno.php");
            include_once ($_SERVER['DOCUMENT_ROOT']."/MYSQLI_Completo/bbdd_models/bdalumnos.php");
            $bdAl=new BD_alumnos();
            $alumno=new Alumno($_POST['nombre'],$_POST['nota'],$_POST['curso']);
		  
		if ($bdAl->anyadir($alumno)==0)
			echo "no se ha podido añadir alumno";
		else           
			header('Location: http://localhost/MYSQLI_Completo');
		
		}
		
		
		
 ?>