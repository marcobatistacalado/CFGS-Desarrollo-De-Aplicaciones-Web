<?php
    
    include_once (dirname(dirname(__FILE__)).'/bbdd_models/bdalumnos.php');
    if (!isset($_GET['curso'])){
        header("Location: ../index.php");
        exit;}
    else{
        $bdAl=new BD_alumnos();
        $lista=$bdAl->listar_curso($_GET['curso']);
    }
?>
       
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <table border=2 align="center">       
        <tr> <td>ALUMNO</td><td>NOTA</td>
       <?php
        foreach($lista as $alumno)
			echo '<tr><td>' .$alumno->getNombre() .'</td><td>'.$alumno->getNota().'</td></tr>';
        ?>
    </table>
</body>
</html>
       