
<?php
    //include_once('../config/global.php');
   // include_once (__ROOT__.'/bbdd_models/bdalumnos.php');
    include_once (dirname(dirname(__FILE__)).'/bbdd_models/bdalumnos.php');
    
    $bdAl=new BD_alumnos();
    $lista=$bdAl->listar_Todos();
    ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
 
   <table border=2 align="center">    
    <tr> <td>ALUMNO</td><td>NOTA</td>
       <?php
        foreach($lista as $alumno)
			echo '<tr><td>' .$alumno->getNombre() .'</td><td>'.$alumno->getNota().'</td></tr>';
        ?>
        </table>
</body>
</html>