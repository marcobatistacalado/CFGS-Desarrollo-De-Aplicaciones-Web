<?php
    if ( isset($_POST['Borrar'])){
		include_once ($_SERVER['DOCUMENT_ROOT']."/MYSQLI_Completo/bbdd_models/bdalumnos.php");
        $bdAl=new BD_alumnos();
		if ($bdAl->eliminar($_POST['codigo'])==0)
			echo "no se ha podido eliminar alumno";
		else
			header('Location: ../index.php');
		
		}
else{
?>
    <!DOCTYPE html>
		<html lang="en">
		<head>
		    <meta charset="UTF-8">
		    <title>Document</title>
		</head>
		<body>
		<form action="<?php echo $_SERVER['PHP_SELF']?>" method="post">
			<p>Introduce código: <input type="text" name="codigo"> </p>
			<p><input type="submit" name="Borrar" value="Eliminar"> </p>	
		</form>
		</body>
</html>
<?php } ?>