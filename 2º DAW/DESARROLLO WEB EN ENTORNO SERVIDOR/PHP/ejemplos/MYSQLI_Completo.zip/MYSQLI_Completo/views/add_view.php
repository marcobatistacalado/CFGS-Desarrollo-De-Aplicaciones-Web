<!DOCTYPE html>
		<html lang="en">
		<head>
		    <meta charset="UTF-8">
		    <title>Document</title>
		</head>
		<body>
		    <form action="../controller/add.php" method="post">
			<p>Nombre: <input type="text" name="nombre"> </p>
			<p>Nota: <input type="text" name="nota"> </p>
			<p>Curso <select name="curso">
						<option>DAW</option>											
						<option>ASIR</option>		
						<option>FIN</option>							
					 </select> 
				
			<p><input type="submit" name="registrar" value="Registrar"> </p>	
		</form>
		</body>
		</html>
		