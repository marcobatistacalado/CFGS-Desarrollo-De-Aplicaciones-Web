<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form action="../controller/buscar.php" method="post">
			<p>Introduce código: <input type="text" name="codigo"> </p>						
			<p><input type="submit"  name="buscar" value="Buscar"> </p>	
    </form>
</body>
</html>