<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   <?php
    $nombre=$_POST["first_name"];
    $apellidos=$_POST["last-name"];
    $edad=$_POST['age'];
    $email=$_POST['email'];
    ?>  
    <h1>EJEMPLO PASO VARIABLES CON GET</h1>  
    <hr>
    <b>Bienvenid@, </b> <?php echo $nombre."  $apellidos" ;?>
    <br>
    Te conservas muy bien para tener <b><?php echo $edad ?></b> años
    <br><br>
    <a href="page3.php?n=<?php echo $email ?>">Enlace</a>
    
</body>
</html>
