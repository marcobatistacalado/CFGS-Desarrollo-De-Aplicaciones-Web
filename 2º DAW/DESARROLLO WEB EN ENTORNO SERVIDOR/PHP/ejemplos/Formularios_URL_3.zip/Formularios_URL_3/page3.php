<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   <?php
   $nombre=$_GET["n"];
echo $nombre;
?>

    </body>
</html>