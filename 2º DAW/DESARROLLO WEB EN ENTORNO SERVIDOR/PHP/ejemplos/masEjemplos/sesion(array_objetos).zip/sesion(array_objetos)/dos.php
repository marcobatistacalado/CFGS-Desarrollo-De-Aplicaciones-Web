<?php
session_start();
include("models/usuario.php");    
if (!isset($_SESSION['usuarios']))
		$_SESSION['usuarios']=array();

$user=new Usuario($_POST['usuario'],$_POST['clave']);		
array_push($_SESSION['usuarios'], $user);
//print_r($_SESSION['usuarios']);
echo 'Bienvenido a la segunda '. $_POST['usuario']; 
echo '<br><a href="tres.php" > Siguiente </a>'
?>