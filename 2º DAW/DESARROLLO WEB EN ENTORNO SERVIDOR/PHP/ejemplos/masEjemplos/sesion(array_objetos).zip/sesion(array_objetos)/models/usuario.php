<?php
class Usuario{
    private $user;
    private $password;
   
    
public function __construct ($u,$p)
 {
     $this->user=$u;
     $this->password=$p;
     
 }
    
public function getUser(){
     return $this->user;
}


    
public function getPassword(){
        return $this->password;
    }
    
}

?>