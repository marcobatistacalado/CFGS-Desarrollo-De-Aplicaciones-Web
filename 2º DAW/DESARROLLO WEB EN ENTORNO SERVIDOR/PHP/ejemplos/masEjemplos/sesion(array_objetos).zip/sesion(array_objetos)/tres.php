<?php
include("models/usuario.php");
session_start();
echo 'Bienvenidos a la tercera<br>' ; 
foreach ( $_SESSION['usuarios'] as $usu)
	{
	echo 'Usuario: ' .$usu->getUser(). '<br>';
	}
session_destroy();	
?>