<?php
if (isset($_REQUEST['pos']))
  $inicio=$_REQUEST['pos'];
else
  $inicio=0;
?>
<html>
<head>
<title>Problema</title>
</head>
<body>
<?php
$conexion=mysql_connect("localhost","root") or
  die("Problemas en la conexion");
mysql_select_db("colegio",$conexion) or
  die("Problemas en la selecci�n de la base de datos");
$registros=mysql_query("select * from alumnos limit $inicio,2", $conexion) or
  die("Problemas en el select:".mysql_error());
  //la cl�usula limit delimita la posici�n desde donde se obtienen resgistros en la bbdd y la cantidad de ellos que obtendremos con select
$impresos=0;
while ($reg=mysql_fetch_array($registros))
{
  $impresos++;
  echo "Codigo:".$reg['codigo']."<br>";
  echo "Nombre:".$reg['nombre']."<br>";
  echo "Curso:".$reg['curso']."<br>";
  echo "<hr>";
}
mysql_close($conexion);
if ($inicio==0)
  echo "anteriores "; //para no tener enlace a anterior p�gina puesto que estoy en los dos primeros
else
{
  $anterior=$inicio-2;
  echo "<a href=\"paginar.php?pos=$anterior\">Anteriores </a>";
}
if ($impresos==2)
{
  $proximo=$inicio+2;
  echo "<a href=\"paginar.php?pos=$proximo\">Siguientes</a>";
}
else
 /* if ($impresos==0)
	header('Location:paginar.php?$pos=0');
  else*/
  echo "siguientes"; //para no tener enlace a siguiente p�gina puesto que no hay m�s resgistros
?>
</body>
</html> 
