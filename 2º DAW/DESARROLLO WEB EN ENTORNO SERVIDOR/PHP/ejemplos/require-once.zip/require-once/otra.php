<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <?php
    require_once("recursos.php");
    cabeceraPagina("Esta es la segunda página");
    echo "<br><br><center>Este es el cuerpo de la segunda página<br><br>
    de este ejemplo</center>";
    piePagina("Pie de la página segunda");
    ?>
</body>
</html>