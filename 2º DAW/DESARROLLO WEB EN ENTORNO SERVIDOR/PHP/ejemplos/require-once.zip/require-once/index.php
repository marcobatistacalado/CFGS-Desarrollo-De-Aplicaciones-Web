<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <?php
    require_once("recursos.php");
    cabeceraPagina("Titulo principal de la página");
    echo "<br><br><center>Este es el cuerpo de la página<br><br></center>";
    piePagina("Pie de la página");
    ?>
    <a href="otra.php">Pulsa aquí</a>
</body>
</html>