<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   <?php
    if (isset($_POST["Aceptar"] )){
        if ($_POST["nombre"]!="" and $_POST["edad"]!="")           
            header("Location:page2.php");
         else
            echo "Campos Obligatorios";
    }
    ?>
    <form action="<?php $_SERVER['PHP_SELF']?>" method="post">
        Nombre<input type="text" name="nombre" >
        <br>
        Edad <input type="text" name="edad">
        <input type="submit" name="Aceptar" value="Aceptar">    
    </form>
    
    
</body>
</html>