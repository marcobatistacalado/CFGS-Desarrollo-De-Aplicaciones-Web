<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   <h1>EJEMPLO PASO VARIABLES CON POST</h1>  
    <hr>
  
   
    <b>Bienvenid@, </b> 
    <br>
    Te conservas muy bien 
        
</body>
</html>