<?php
define('__ROOT__', dirname(dirname(__FILE__))); 
//rutas en los includes/requiere. Si dan problemas absolutas respecto de localhost/hosting
//require_once($_SERVER["DOCUMENT_ROOT"]."/MYSQLI_Completo/models/alumno.php");
//require_once(__ROOT__.'/models/alumno.php');
?>