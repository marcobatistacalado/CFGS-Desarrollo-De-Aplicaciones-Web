<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
</head>
<body>
    



<?php
    
 
include('../config/global.php');
include (__ROOT__.'/bbdd_models/bdalumnos.php');
if (!isset($_POST['accion']))
      header('Location: http://localhost/MYSQLI_Completo');
else{
$bdAl=new BD_alumnos();
$ac=$_POST['accion'];

switch ($ac)
{
case 'verTodos':
        echo '<table border=2 align="center">';       
        echo '<tr> <td>ALUMNO</td><td>NOTA</td>';
        $lista=$bdAl->listar_Todos();
        foreach($lista as $alumno)
			echo '<tr><td>' .$alumno->getNombre() .'</td><td>'.$alumno->getNota().'</td></tr>';
        echo '</table>';
		break;
		
case 'alumnosCurso':
		echo '<table border=2 align="center">';       
        echo '<tr> <td>ALUMNO</td><td>NOTA</td>';
        $lista=$bdAl->listar_curso($_POST['curso']);
        foreach($lista as $alumno)
			echo '<tr><td>' .$alumno->getNombre() .'</td><td>'.$alumno->getNota().'</td></tr>';
		 echo '</table>';		
		break;
case 'insertar':
		if ( isset($_POST['registrar'])){
            $alumno=new Alumno($_POST['nombre'],$_POST['nota'],$_POST['curso']);
		  print_r($alumno);    
		if ($bdAl->anyadir($alumno)==0)
			echo "no se ha podido añadir alumno";
		else           
			header('Location: http://localhost/MYSQLI_Completo');
		
		}
		
		else{
		?>
		<form action="operaciones.php" method="post">
			<p>Nombre: <input type="text" name="nombre"> </p>
			<p>Nota: <input type="text" name="nota"> </p>
			<p>Curso <select name="curso">
						<option>DAW</option>											
						<option>ASIR</option>		
						<option>FIN</option>							
					 </select> 
				<input type="hidden" name="accion" value="insertar">
			<p><input type="submit" name="registrar" value="Registrar"> </p>	
		</form>
	<?php	}
		
		break;
case 'eliminar':
	if ( isset($_POST['Borrar'])){
		
		if ($bdAl->eliminar($_POST['codigo'])==0)
			echo "no se ha podido eliminar alumno";
		else
			header('Location: http://localhost/MYSQLI_Completo');
		
		}
else{
?>
		<form action="operaciones.php" method="post">
			<p>Introduce código: <input type="text" name="codigo"> </p>
			<input type="hidden" name="accion" value="eliminar">
			<p><input type="submit" name="Borrar" value="Eliminar"> </p>	
		</form>
<?php }
		break;
case 'modificar':
			if ( isset($_POST['cambiar'])){
				if ( $bdAl->modificar($_POST['codigo'],$_POST['notaNueva'])==0)				
					echo "no se ha podido modificar alumno";
				else
					header('Location: http://localhost/MYSQLI_Completo');
			}
			else{
			if ( isset($_POST['buscar'])){
				$alumno=$bdAl->buscarAlumno($_POST['codigo']);              
				if ($alumno==null)
				    echo "no existe ese alumno";
				else{
				echo '<form action="operaciones.php" method="post">';
				echo '<p>Nombre: <input type="text" name="nombre" value='. $alumno->getNombre().'> </p>';
				echo '<p>Nota: <input type="text" name="nota" value='. $alumno->getNota().'> </p>';
				echo '<p>Nueva Nota: <input type="text" name="notaNueva" > </p>';
				echo '<p><input type="submit" name="cambiar" value="cambiar"> ';
				echo '<input type="button" value="Cancelar" onClick="location.href=\'../index.html\' "></p> ';
				echo '<input type="hidden" name="codigo" value='. $alumno->getCodigo().'>';
				echo '<input type="hidden" name="accion" value="modificar">';				
				echo '</form>';
				}
			} else{
?>
		<form action="operaciones.php" method="post">
			<p>Introduce código: <input type="text" name="codigo"> </p>						
			<p><input type="submit"  name="buscar" value="Buscar"> </p>	
			<input type="hidden" name="accion" value="modificar">
		</form>

<?php } }
		break;
	
	
}
 }
 
?>
</body>
</html>