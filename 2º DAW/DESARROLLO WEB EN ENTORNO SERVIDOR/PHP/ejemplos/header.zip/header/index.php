<html>
	<head>
		<title></title>
	</head>
	<body>
		<html>
	<head>
		<title>Formulario</title>
	</head>
	<body>
		<form action='verValor.php'  method='POST'>
        <p>Introduce Valor <input type=text  name=valor /></p>
        
        <p><input type=submit VALUE=Enviar></p>
        </form>
	</body>

</html>

	</body>

</html>
