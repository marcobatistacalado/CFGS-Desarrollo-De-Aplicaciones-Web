<?php
if (!isset($_POST['valor']) ){
	//die('acceso no permitido');
    header("Location:principal.html");
}
else
	{
	$valor=$_POST['valor'];
	if ($valor%2==0)
		header("Location:par.php?valor=$valor");
	else
		header("Location:impar.php?valor=$valor");
		//header("Location:http://localhost/ejemplos/otro.php");
		//header ('Refresh: 5; url=http://www.google.es');
	}
?>	