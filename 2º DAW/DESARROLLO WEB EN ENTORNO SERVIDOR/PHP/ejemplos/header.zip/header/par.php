<?php
echo 'Pares: ' . $_GET['valor'];

?>