<?php
echo 'Imapares '. $_GET['valor'];

?>