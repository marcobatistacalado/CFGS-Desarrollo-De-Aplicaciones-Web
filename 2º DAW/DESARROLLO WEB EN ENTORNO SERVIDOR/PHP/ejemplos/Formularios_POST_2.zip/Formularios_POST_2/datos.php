<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <?php
	if (!isset($_POST["enviar"]))
        header("Location:index.php");
	
	echo "Bienvendio Sr(a) ".$_POST['nombre'];
	echo "<br> La dirección de correo ". $_POST['email'] ." queda registrada<br><br>";
    if (!isset($_POST['aficiones']))
         echo "<br>No tienes aficiones";
    else{
	$lista=$_POST['aficiones'];
    echo "Tus aficiones";
	foreach ($lista as $aficion)
		echo "<br>$aficion";
    }
?>

</body>
</html>