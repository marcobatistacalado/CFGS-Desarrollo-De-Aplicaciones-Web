<html>
	<head>
		<title>Formulario</title>
	</head>
	<body>
		<form action='datos.php'  method='POST'>
        <p>Introduce Nombre <input type=text  name=nombre /></p>
        <p>Introduce Email  <input type=text  name=email /></p>
		<p>Aficiones<p>
		<p>Musica<input type='checkbox' name='aficiones[]' value='musica'/></p>	
		<p>Deportes<input type='checkbox' name='aficiones[]' id='id_deporte' value='deporte'/></p>   
        <p>Lectura<input type='checkbox' name='aficiones[]' value='lectura'/></p>	
        <p>Viajes<input type='checkbox' name='aficiones[]' value='lectura'/></p>	
        <p><input type=submit name="enviar" VALUE="Enviar" /></p>
        </form>
	</body>

</html>

