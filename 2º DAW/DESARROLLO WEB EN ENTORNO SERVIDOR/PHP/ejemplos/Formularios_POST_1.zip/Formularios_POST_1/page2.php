<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
   <h1>EJEMPLO PASO VARIABLES CON POST</h1>  
   <hr>
   <?php
    if (!isset($_POST["Aceptar"]))
          header("Location:index.php");
    $edad=$_POST["edad"];
    ?>  
   
    <b>Bienvenid@, </b> <?php echo $_POST["nombre"];?>
    <br>
        Te conservas muy bien para tener <b><?php echo $edad; ?></b> años
</body>
</html>