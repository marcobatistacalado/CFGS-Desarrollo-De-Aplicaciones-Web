<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <form action="page2.php" method="post">
        Nombre <input type="text" name="nombre" >
        <br><br>
        Edad <input type="text" name="edad">
        <input type="submit" name="Aceptar" value="Aceptar">    
    </form>
    
    
</body>
</html>