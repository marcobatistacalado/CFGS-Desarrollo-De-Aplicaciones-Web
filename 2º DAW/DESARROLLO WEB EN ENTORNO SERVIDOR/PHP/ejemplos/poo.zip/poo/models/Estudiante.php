<?php
class Estudiante{
    private $nombre;
    private $DNI;
    private $edad;
    
 
    
   public function __construct($nombre,$DNI,$edad){
        $this->nombre=$nombre;
        $this->DNI=$DNI;
        $this->edad=$edad;
    }
    
    public function getNombre(){
        return $this->nombre;
    }
    
    public function __tostring(){
        return "Nombre: ".$this->nombre."<br>Dni: ".$this->DNI."<br>Edad:". $this->edad;
    }
    
}
?>