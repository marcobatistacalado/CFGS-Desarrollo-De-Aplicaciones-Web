<?php
include"Estudiante.php";

class EstudianteFP extends Estudiante{
    
    private $ciclo;
    
    public function __construct($ciclo, $nombre,$DNI,$edad=0){
        parent::__construct($nombre,$DNI,$edad);
        $this->ciclo=$ciclo;
    }
    
    public function getCiclo(){
        return $this->ciclo;
    }
}

?>