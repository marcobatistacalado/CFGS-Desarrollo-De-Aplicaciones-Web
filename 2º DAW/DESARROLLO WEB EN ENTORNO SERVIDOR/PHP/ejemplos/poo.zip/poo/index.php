<?php
include "models/EstudianteFP.php";
$e=new Estudiante("pepe","111111A",20);
$efp=new EstudianteFP("DAW","ana","222222B");

echo $e;
echo "<br>-------------<br>";
echo $efp->getNombre(). " -  ". $efp->getCiclo()."<br>-------------<br>";
echo $efp;


?>